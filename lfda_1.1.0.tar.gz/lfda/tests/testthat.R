library(testthat)
library(lfda)

test_check("lfda")
