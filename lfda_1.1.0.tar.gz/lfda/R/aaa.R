
#Avoid false positives in R CMD CHECK:
utils::globalVariables(c("Class"))
