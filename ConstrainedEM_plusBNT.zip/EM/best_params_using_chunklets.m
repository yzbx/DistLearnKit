function [bestParam] =best_params_using_chunklets(data,chunklets,M,...
    singleCovMatFlag,diag_covmat_flag,priorFlag,number_of_starts)

% this function finds start conditions for the mixture parameters.
% if chunklets are given , they are used in the process.
% currently only single covmat is supported.

%priorFlag  - if 1 will use smoothing in RCA cov estimation. default
%is zero
if(~exist('number_of_starts'))
    number_of_starts=30;
end

if(~exist('priorFlag'))
  priorFlag=0;
end

if(~exist('diag_covmat_flag'))
  diag_covmat_flag=0;
end

% M -the number of models
[ n , dim ]=size(data);

bestParam=cell(M,3);

% wishart prior option :	% this is a prior on the covmat assessed by RCA. the prior
% is used if the flag is on.
% according to 'priors on dag models' of Heckerman and Geiger, p. 10

wishart_prior_flag=1;	
T=eye(dim);		% the prior covmat.
alpha=n/20;		% the prior 'virtual sample' size.


if singleCovMatFlag
   % the model weights are equiprobable
   for i=1:M
        bestParam{i,3}=1/M;  % uniform weights
    end
   
   % do RCA for the covmat

   [WhitenedData, bestParam{1,2} ]= RCAwhitenChunklets(chunklets,data',priorFlag);
   if wishart_prior_flag==1
      m=length(find(chunklets~=-1));
      Sm=bestParam{1,2}*m;
      bestParam{1,2}=(alpha*T+Sm)/(m+alpha);	% is this the map for a wishart distribution?
						% it needs to be determnied.
   end
                                          
   if(diag_covmat_flag)
     bestParam{1,2}= bestParam{1,2}.*T;
   end
   
   % find centers
   
    bll=-inf;       % best log liklihood.
   i=1;
   infFlag= 1;
   noiseParam=[2 5 10];	 % alters the number of neighbors to be used for
   % choosing centers. when large, the number of  neighobrs used for
   % centroid computation is smaller.
   while (i <= number_of_starts) 
      param = select_start_params(data,bestParam,singleCovMatFlag,1,M,dim,n,noiseParam(ceil(i/10)),chunklets); 
      [p , ll ]=calc_p_and_ll(data,param,singleCovMatFlag);
      if ll>=bll
         bll=ll;
         bestParam=param;
      end
      i= i+1;
      if(bll ~= -inf)
         infFlag=0;
      end
   end
   if infFlag==1
      bestParam=[];
   end
else 
   ' ou est le chien ? '
end


