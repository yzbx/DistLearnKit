function [results,logLikelihood ,groups ,z ]=calculate_labeled_model(data,k, ...
   single_cov_mat_flag,ClassLabels,neutral_globals_flag )
                            
% k                         : the number of componenets.
% data                      : the data - every row is a data point.
% single_cov_mat_flag       : if 1 - a single covariance matrix is used . else - k matrixes.
% ClassLabels               : if sent, the labels are used to asses the purity_acuracy score at every 
%                             iteration. the results are returned at z.

% results                   : the best parameters achieved
% logLikelihood             : a log of the ll decrease.
% groups                    : the prefered centers for the points.
% z                         : a vector where 1= purity, 2= accuarcy, 3= sZcore
% neutral_globals flag			: null all the globals before calculation 
%											to be used when called from create_mog_data
% important parameters :
                     
s=size(data);
d=s(2);     % the dimension.
n=s(1);     % the number of samples.
global anti_chunk_num;
global chunklet_sizes;
global mm_flag;
global nets;	% not really needed. it is defined just for technical programming reason
				% ( calculate_partition_function2 used in maximize assumes it exists )
            
if ~exist('neutral_globals_flag')
   neutral_globals_flag=0;
end
if neutral_globals_flag
   anti_chunk_num=0;
   chunklet_sizes=[];
   mm_flag=0;
   nets=[];
end

global late_oracle;
late_oracle=0;

% prepare pseudo-probability matrix and other pseudo variables
probabilities=zeros(k,n);
probabilities( (0:k:(n-1)*k )'+ClassLabels)=1;
probabilities=probabilities';
oth=1:length(data);
singles=1:length(data);
nc_inds=1:length(data);

% the globals passed to maximize :
nets=[];
mm_flag=0;
chunklet_sizes=[];
anti_chunk_num=0;

% calculate the Labeled parameters.
results=maximize(data,k,0,probabilities,oth,single_cov_mat_flag,0,0,0,0);
% caculate the assignment
[ probabilities , logLikelihood , groups ] =calc_ass_and_maxll(data,results,single_cov_mat_flag...
                                                        ,[],nc_inds,singles);
% calculate the purity - acuracy score
[a2 , b2]=purity_accuracy2(ClassLabels,groups,k);
z=[a2, b2, 2*a2*b2/(a2+b2)];


