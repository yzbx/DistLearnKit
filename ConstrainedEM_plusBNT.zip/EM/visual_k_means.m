function visual_k_means(data,l1,ttl)

figure;
hold on;
colors=['rgbykcm'];
k=max(l1);

for i=1:k
   str=[colors(i),'.'];
   inds=find(l1==i);
   if ~isempty(inds)
      plot(data(inds,1),data(inds,2),str);
   end
end

title(ttl);

