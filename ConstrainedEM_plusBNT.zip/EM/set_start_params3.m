%last modified by Tomer 22/6/02 14:13

% set_start_params3
dont_mark_nei_f=1;	% when set, only the seed point is removed from candidate list
% 					for the next seeds. when not set, all the neighbourhood is removed.
use_chunklet_info_f=0;	% when set , the centers are choosen after a chunklet closure
%					operator has been applied to the neighbourhood.

cluster_size=floor(n/k);
used_flags=zeros(n,1);
noise_param=1;
%keyboard
for j=1:k
    % randomize cluster seed
    seed_ind=floor(rand*(n-1))+1;
    while used_flags(seed_ind)      % find unused seed
        seed_ind=floor(rand*(n-1))+1;
    end
    
    if dont_rand_covmat_flag==1       % rand only centers
        param{j,1}=data(seed_ind,:);
        used_flags(seed_ind)=1;
    else                              % rand centers and cov matrices
        seed=data(seed_ind,:); 
        
        %find neighbourhood  
        
        dists=sum(((data-ones(n,1)*seed).^2)');
        [ tmp inds ]=sort( dists );
        number_of_nei=max(round(n/(k*noise_param)),d+1);
        inds=inds(1:number_of_nei);
        
        % include chunklet closure in the choosen neighbours
        if (ch_num>0) & ( use_chunklet_info_f==1)
            inds2=find (chunks(inds)~=-1);
            c_inds=unique(chunks(inds(inds2))); % indexes of chunklets to add.
            for jj=1:length(c_inds)      % adding the chunklets
                inds=union(inds,find(chunks==c_inds(jj)));
            end
        end
        
        if dont_mark_nei_f==1
            used_flags(seed_ind)=1;
        else
            used_flags(inds)=1;
        end
        
        % set params
        param{j,2}=cov(data(inds,:));
        param{j,1}=mean(data(inds,:));
    end
end
    
if (single_cov_mat_flag==1)&(dont_rand_covmat_flag==0)
    % unify the cov matrixes ( mean them ) and put the result in param{1,2}
    tmp=zeros(d,d);
    for j=1:k
        tmp=tmp + param{j,2};
    end
    param{1,2}=tmp/k;
    %clear all other cov mats!!!!!
    for j=2:k
      param{j,2}= [];
    end
    
end




   
   
   
