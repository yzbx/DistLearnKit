
function [table]= pilug(data)

minVal= min(data);
maxVal= max(data);

temp= unique(data);
if(size(temp,1)==1)
  
  table(:,1)= temp';
else
  table(:,1)= temp;
end

for i=1:length(temp)
    table(i,2)= length(find(data==table(i,1)));
end
    