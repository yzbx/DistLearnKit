%computes RCA of data 

%params:

% TrainingSet - The data points as an N*D matrix, where N is the number of data points,
% D the dimension of the data. Each data point is a row in the matrix.

% chunkletAssignments - a vector of size N*1 describing the chunklets :                       
%               -1 in the i'th place says that point i doesn't belong to any chunklet
%               integer j in place i says that point i belongs to chunklet j.
%               The chunklets indexes should be 1:number_of chunklets

% priorFlag - when this flag is set, the cov matrix is check for ill conditioning , and if 
%               it is found to be low rank, it is smothened by addition of eye(D).
%             the default of this flag is 1.

% returns :

% B - the RCA suggested mahalanobis matrix.
% A - the RCA suggested transformation of the data.
% newData - the data after the RCA transformation (A).

% the ouput argument fulfill : newData=A*data
% for every two original data points x1,x2 with new images y1,y2:
%  (x2-x1)'*B*(x2-x1) = Euclid norm of y2-y1 = (y2-y1)'*(y2-y1)

function [ B, A, newData ] = RCA(TrainingSet,chunkletAssignments,priorFlag)

if(~exist('priorFlag'))
    priorFlag=1;
end

TrainingSet=TrainingSet';	% tomer conversion
S= max(chunkletAssignments);
ChunkletDataSet= [];
ChunkletSizes= [];
for i=1:S
    inds= find(chunkletAssignments == i);
    ChunkletSizes(i)= length(inds);
    ChunkletDataSet= [ChunkletDataSet TrainingSet(:,inds)];
end

[CenteredChunklets]=centerChunklets(ChunkletDataSet,ChunkletSizes);

%compute the svd of the normalized chunklets
Cov= CenteredChunklets*CenteredChunklets';
[dim N]= size(CenteredChunklets);

%check for ill ranked RCA covmat in case of not enough chunklets: if
%so smooth matrix:
alpha= N/50;
if(priorFlag)&(rank(Cov) < dim)
    Cov= (Cov + alpha.*eye(dim))/(sum(ChunkletSizes)+alpha);
else  
    Cov= Cov./N;
end

[U Sig V]= svd(Cov);

% whiten the data set using RCA Transformation:

A=(Sig^-0.5)*U';
newData = A*TrainingSet;

% the mahalanovis matrix
B=inv(Cov);


%%%%%%%%%%% end of RCA function



% This function computes the centroid of each chunklet and substracts it from all
% chunklet members.
% ChunkletSizes is a vector containing the size of each chunklet in the data set.
% chunklets are assumed to be ordered.

%HANADLES situations where the chunklet is of size 1.

function [CenteredChunklets]= centerChunklets(DataSet, ...
    ChunkletSizes)

[rows cols]= size(DataSet);

numOfChunklets= length(ChunkletSizes);
i=1;

for k=1:numOfChunklets
    
    if(~ChunkletSizes(k)==0)
        centroid= mean(DataSet(:,i:i+ChunkletSizes(k)-1)');
        
        DataSet(:,i:i+ChunkletSizes(k)-1)= DataSet(:,i:i+ChunkletSizes(k)-1)- ...
            (centroid'*ones(1,ChunkletSizes(k)));
    end
    
    i= i+ChunkletSizes(k);
end

CenteredChunklets= DataSet;
