% this function chooses initial conditions for an EM based on 
%   data - the data
%   param - empty param matrix. optionaly param{1,2} is filled. in this
%   case the covariance matrix used is param{1,2} and the covmat isn't
%   randomized.
%   scmf - single covmat flag
%   drcf - dont rand covmat flag
%   chunks - chunklets
%   ch_num - number of chunklets
%   nc_inds - indexes of non- chunkleted points
%   number_of_starts - the number of starting conditions tried.

% if reasonable RCA is used in the process.

function param=best_params_general(data,param,scmf,...
chunks,ch_num,nc_inds,number_of_starts);

M=size(param,1);

if ~isempty(param{1,2})
    drcf=1;
else drcf=0;
end

if ~exist('number_of_starts')
    number_of_starts=30;
end

if scmf==1 & ~isempty(chunks)   % if usefull, do RCA based initialization
    param=  ...              
    best_params_using_chunklets(data,chunks, M, scmf, drcf ,0,number_of_starts);
else    % do simple initialization
   param=best_params(data,param,scmf,drcf,chunks,ch_num,nc_inds,number_of_starts);
end

% initialize cluster weights
for i=1:M
    param{i,3}=1/M;
end
