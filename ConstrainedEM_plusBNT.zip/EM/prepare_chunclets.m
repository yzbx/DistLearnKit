function inds =prepare_chunclets(cSizes,chun_num,av_chun_size,std_chun_size)
% cSizes - size of classes
% chun_num - number of chunclets.
% av_chun_size - average chunclet size
% if chunklets are not disjoint the intersection belong only to one of them , and the other becomes smaller.
% inds - a cell(1,chun_num) containing the indexes of the points in chunklets.

limits=[0 cumsum(cSizes) ];
unused_flags=ones(1,limits(end));
nc=length(cSizes);
inds=cell(chun_num,1);
for i=1:chun_num
    chunklet_not_ready=1;
    while chunklet_not_ready==1
        seed=floor(rand*limits(end))+1; % first member in chunclet
        
        tmp=limits<seed;
        class=find(diff(tmp)==-1);      % the class of the chunclet
        range=(limits(class)+1):limits(class+1);    
        range=setdiff(range,seed);
        
        chun_size=round(randn(1,1)*std_chun_size)+av_chun_size; % the chunclet size
        if chun_size<=0 
            chun_size=1;
        end
        
        if chun_size>=cSizes(class)     % chunklet with size of the whole class.
            inds{i}=(limits(class)+1):limits(class+1);
        else
            choosen=1;              % choosing the chunclet members.
            inds{i,choosen}=seed;
            while choosen<chun_size
                ind=floor(rand*(length(range)-0.001))+1;
                choosen=choosen+1;
                inds{i}(choosen)=range(ind);
                range=[ range(1:ind-1) range(ind+1:end) ];
            end
        end
        inds{i}=inds{i}( logical( unused_flags( inds{i} ) ));  % drop the used points 
        unused_flags(inds{i})=0;
        if ~isempty(inds{i}) % the chunklet is not empty
            chunklet_not_ready=0;
        end
    end
end

    
    
    
    
    