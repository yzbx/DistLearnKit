function cov_mat=calc_chunk_cov_mat(data,inds);
% data - the data ( in rows )
% inds - cell array containing in each cell indexes of a chunclet group.
l=length(inds);
sz=size(data);
cov_mat=zeros(sz(2),sz(2));


for i=1:l
    tmp_dat=data(inds{i},:);
    cs=length(inds{i});
    m=mean(tmp_dat);
    cov_mat=cov_mat+(tmp_dat-ones(cs,1)*m)'*(tmp_dat-ones(cs,1)*m);
end


    

