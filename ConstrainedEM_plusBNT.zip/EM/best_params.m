% last modified by tomer 25.6 - solve situation when all 30 initial
% conditions result in ll= -inf

% last modified by noam 22.6
% this best_params is intended to work only when labels are NOT available 
% or in they are not taken into consideration in choosing the initial conditions
% see lines 18-20

function res=...
best_params(data,param,single_cov_mat_flag,dont_rand_covmat_flag,...
chunks,ch_num,nc_inds,number_of_starts)
% chooses the best out of number_of_trials random start params

% returns the param variable sent, filled with the best parameters achieved
% sets the centers and the cov-matrixes, not the weights

% if the function is called without the last 3 params, no chunklets are assumed.
% if the function is called without the last 2 params, they are calculated here.

if ~exist('number_of_starts')
    number_of_starts=30;
end

s=size(param);
k=s(1);
s=size(data);
d=s(2);     % the dimension.
n=s(1);     % the number of samples.


if (nargin<7)					% chunklet information have to be calculated
    if ~exist('chunks')
      chunks=[];
   end

   % this code is copied from mixture_of_gaussians2
   if ~isempty(chunks)     % collect usful chunklets statistics.
      ch_num=length(unique(chunks))-1;
      for i=1:ch_num      
         chunk_sizes=length(find(chunks==i));
      end
      number_of_hiddens=n-sum(chunk_sizes)+ch_num;
      global nc_inds;
      nc_inds=find(chunks==-1);   % nc_inds - non chunkletted data indexes
   else                    % no chunklets
      ch_num=0;
      chunk_sizes=[];
      number_of_hiddens=n;
      nc_inds=1:length(data);
   end
end

if isempty(param{1,3})          %if there isn't initialization - initialize cluster weights
   for i=1:k
      param{i,3}=1/k;
   end
end


% find the best params loop 

bll=-inf;       % best log liklihood.
best= [];       % best params.

i=1;
infFlag= 1;

while( (i <= number_of_starts) | (infFlag) )
%for i=1:number_of_starts tomer's chnage
   set_start_params3;
   [p , ll , c_p ]=calc_p_and_ll2(data,param,single_cov_mat_flag,chunks,ch_num,nc_inds);
   if ll>=bll
      bll=ll;
      best=param;
   end
   i= i+1;
   if(bll ~= -inf)
     infFlag=0;
   end
   
end

res=best;



