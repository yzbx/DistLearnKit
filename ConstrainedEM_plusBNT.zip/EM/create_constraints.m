% this is an inner script of test_constrainedEM.
% it finds noc ( number of constraints ) constraints and build the chunk 
% (positive constraints data structure) and the anti_chunks (negative
% constraints data structure) variables.

chunks=-ones(data_size,1);
    anti_chunks=[];
    cc=0;
    acc=0;
    for i=1:noc
        xy=floor(rand(1,2)*data_size)+1;
        if (xy(1)~=xy(2))
            if (data(xy(1),3)==data(xy(2),3))
                if ( ( chunks(xy(1))~=-1 ) & ( chunks(xy(2))~=-1 ) )
                    inds=find(chunks==chunks(xy(1)));
                    chunks(inds)=chunks(xy(2));
                elseif chunks(xy(1))~=-1
                    chunks(xy(2))=chunks(xy(1));
                elseif chunks(xy(2))~=-1
                    chunks(xy(1))=chunks(xy(2));
                else
                    cc=cc+1;
                    chunks(xy)=cc;
                end
            else
                acc=acc+1;
                anti_chunks(acc,:)=xy;
            end
        end
    end
    
    % remove gaps in chunklets indexes.
    
    df=0;
    for i=1:cc
        inds=find(chunks==i);
        if isempty(inds)
            df=df+1;
        end
        chunks(inds)=i-df;
    end
    