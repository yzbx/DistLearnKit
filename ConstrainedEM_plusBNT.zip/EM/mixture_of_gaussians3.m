
% This is the ConstrainedEM function. it gets the data, required number of
% models, chunklets and negative constraints and returns the model found.

% 'Mixture_of_gaussians3' parameters :

% MANDATORY PARAMETERS :

% data                      : the data - every row is a feature vector of a data instance.
%                           ( data(i,:) contains data instance i ). 

% k                         : the number of componenets in the Gaussian mixture. 
%                           The algorithm produces soft clustering of the
%                           data into k Gaussian clusters.

% CONSTRAINTS PARAMETERS :

% chunks                    : Positive constraints vector   (constraints of the form 
%                           'points a and b belong to the same class'). It is an integer
%                           tag vector with dimensions 1*length(data) 
%                         
%                           Entrance i of the vector realtes to data instance i.
%                           When several data points are known to be from the same 
%                           class, their indexes in this vector should be identical
%                           positive integers to indicate the constraint.
%                           A '-1' tag indicates that the data instance
%                           isn't positively constrained.
%                           For example: chunks=[2 -1 2 1 -1 -1 2 ] indicates that :
%                           Data instances 1,3 and 7 are from the same class.
%                           Data instances 4 and 6 are from the same class.
%                           Data instances 2 and 5 are not constrained.
%                           Remember that the sets of instances {1,3,7} and
%                           {4,6} might belong to the same class and might
%                           belong to different classes

% anti _ chunks		        Negative constraints table. (constraints of the form 'points
%                           a and b belong to different classes'). It's a table with 
%                           dimensions (length of data set)*2 containing index pairs 
%                           indicating negative constraints.
%                           Each pair contains the indexes of two data instances which
%                           are known to belong to different classes.
%                           For example anti_chunks=[ 1 ,5 
%                                                     6 ,3
%                                                     1 ,4 ];
%                           indicates that data instances 1 and 5 belong to different
%                           classes. The same statement is true for data
%                           instances 6 and 3, and for data instances 1 and 4.

% ADDITIONAL OPTIONAL PARAMETERS

% param                     :  a cell of kX3 initial conditions : 
%                              the param(:,1) are the Gaussian centers . 
%                              the param(:,2) are the Gaussain covariance matrixes. 
%                              the param(:,3) are the mixture weights (scalars ) 
%                              and they should sum to 1. 
%                           If param is empty or not given initial params are
%                           randomized.
%                           If only param{1,2} isn't empty it is used as
%                           the start covariance matrix, while centers and
%                           weights are randomized.

% ClassLabels               If sent, the labels are used to asses the purity_acuracy score.
%                           the results are returned at z. See also
%                           the internal parameter z_record flag 

% single_cov_mat_flag       1 - A single covariance matrix is used . 
%                           0 - k different covarianc matrixes are used, one for each
%                           Gaussian model.
%                           When multiple covariance matrixes are used, the model 
%                           is more expressive and has many more parameters. However, 
%                           in this case a larger amount of data is needed to accomplish
%                           sucssesfull learning. 
%                           The default value is 1 (single covariance matrix)

% late_oracle				: This flag indicates which statistical model is used when
%                           updating the mixture weights parameters. For an explanation
%                           of the two possible models one if reffered to the the paper:

%                           'Computing mixture models with EM using side information
%                           (Equivalence Constraints)' in "The Continuum from Labeled
%                           to Unlabeled Data in Machine Learning and Data Mining", 
%                           Workshop in ICML 2003.

%                           When this flag is 0, 'early oracle' model is used.
%                           When it is 1, 'late oracle' is used. The 'early oracle'
%                           model has a closed form solutions for the weigfhts update, 
%                           and hence it is faster. The 'late oracle' model is slower,
%                           but is more adequate in some scenarios, especially when
%                           both positive and negative constraints are used.
%                           The default value is 1.

% calc_grad_num		        : This parameter is only meaningfull when negative constrains
%                           are available and the parameter aa_flagP=0. When aa_flagP=0
%                           no approximation of the partition function is used and the
%                           algorithm performs gradient descent where the gradient is 
%                           accuratley computed using a Markov network. Since this 
%                           process is slow we have to limit the number of such gradient
%                           computations. calc_grad_num is the maximum number of such
%                           gradient computations in a single EM update.
%                           The defalut value is 0 (since the defalut of aa_flagP is 1 -
%                           no accurate gradient computation is done.)

% aa_flagP		            : This flag indicates whether the partition function that
%                           arises due to negative constraints is approximated or
%                           computed accurately. The accurate computation is computationaly
%                           expensive and the approximation leads to very similar 
%                           empirical results. Therefore the default value is 1 
%                           (use approximation) and not 0 (use accurate computation).

% reduce_arcs		        : controls pruning of anti chunklet arcs. When many negative 
%                           constraints are used, the Markov network representing them
%                           can become dense, thus render the inference in the 'E' step
%                           infeasible (or painstakingly slow). Thus we may prune the
%                           negative constraint set, until the network is a tree 
%                           (leading to reasonably fast inference). 
%				        	0 - no pruning.
%				        	1 - prune contextually on every EM round
%				        	2 - prune once - only at the begining 
%                           option 1 is problematic both theoretically and
%                           empirically. The default value is 2.

% fixed_covmat              : if 0 (default) the algorithm will estimate covariance 
%                           matrix. If 1 the algorithm will not estimate covariance 
%                           matrix and will use the one given to mixtuer_of_gaussians3 
%                           in the parameter param{1}{2}.

% small_model_policy        : when 0 , small models are removed and no 'grace turn' is given
%                             when 1 , small models are freezed     
%                             when 2 , small models are removed and 'grace turn' is given
%                           Usually the E-M loop stops when the log-likelihood of the
%                           data doesn't increase of decrease. 'grace turn' is an EM 
%                           iteration in which such a decrease of log-likelihood doesn't
%                           cause termination of the E-M loop. This may be required when
%                           we remove a model from the mixture, since such a removel 
%                           decrease the log-likelihood. If the E-M is allowed to
%                           proceed after such an event, it may find better models.
%                           The default value is 2.



% The arguments returned by 'Mixture of Gaussians3':


% results                   : The parameters of the model found. This model gives a 
%                           local maximum to the constrained data likelihood. The 
%                           parameters are given in the a format identical to the format
%                           of the argument 'param'.

% logLikelihood             : A log of the log-likelihood decrease. It is a vector with
%                           dimensions of 1*'numer of EM iterations'. Entrance i of the
%                           vector contains the log-likelihood of the model after i-1
%                           iterations. 

% groups                    : An assignment vector of dimensions 1*(number of data 
%                           instances). The i entrance of the vector contains the MAP 
%                           assignment of data point i (the index of the Gaussian model 
%                           best explaining it). The MAP assignment is computed using 
%                           the constraints network and the mixture model found, and it
%                           thus complies with the constraints (unless many negative 
%                           constraints were used and some of them were pruned since 
%                           aa_flagP=1)

% z                         : When z_record_flag=0 (the default) z returns a vector of 
%                           3 numbers :   1. purity  2. accuarcy  3. z_score
%                           of the final model. The z_score is simply computed as:

%                               2*purity*accuracy/(purity+accuracy)

%                           When z_record_flag=1 a table of dimensions (number of EM 
%                           iterations)*3 is returned. Each triplet z(i,:) contains
%                           (purity, accuracy , z_score) of the model after the i-1 
%                           iteration.

% anti_chunks_pruned        : This is vector containing the indexes of negative 
%                           constraints which were pruned (not considered) in order to
%                           turn the Markov network into a tree. The indexes are indexes
%                           into the anti_chunk table given to mixture_of_gaussians3 as 
%                           parameter. If the index i appears in anti_chunks_pruned then
%                           constraint anti_chunks(i,:) is not considered by the EM.

% exit_flags	            : This argument reports specific problems occured during the
%                           EM run by setting bits on.

%                           bit 1 : the last round decrease the ll
%                           This is usually due to the approximations used for the 
%                           gradient ascent. It is a minor problem.

%       				    bit 2 : the aa_flag was turned off in the midst of EM.
%                           This happends when the approximation of the partition function 
%                           gradient w.r.t the mixture weights fails, and the algorithm
%                           resorts to accurate gradient computation.
%                           This may happends when mixture weights are very extreme (one
%                           very big model and few small ones). The results in this case
%                           may be dissapointing.

%   						bit 3 : one model or more was removed
%                           models are removed when they are too small to
%                           estimate their parameters. The results may
%                           be dissapointing.

%							bit 4 : catastroph : log-likelihood reached -infinity 
%                           or all the models have been deleted. This problems is caused by numeric underflows.
%                           it is very rare and happends only when the data is very high
%                           dimensional. The results in this case are meaningless.

%							bit 5 : a covmat was close to singular during the convergence.
%                           This also happends when a model is small and it's hard to
%                           estimate it's parameters. The results may be
%                           dissapointing.

%							bit 6 : a model was frozen while EM
%                           models are frozen ( do not continue to update) when they are
%                           too small to estimate their parameters, and 
%                           small_model_policy=1. The results may be dissapointing.


function [results,logLikelihood ,groups ,z , anti_chunks_pruned ,exit_flags ]=...
   mixture_of_gaussians3(data,k,chunks, anti_chunks,param, ClassLabels,...
   single_cov_mat_flag, late_oracleP,...
   calc_grad_num,aa_flagP,reduce_arcsP,fixed_covmat,small_model_policy)

% important parameters :

s=size(data);
d=s(2);     % the dimension.
n=s(1);     % the number of samples.

z_record_flag=0;		% when set , a purity-acuracy score record is returned , in which
				% the purity-acuracy score is calculated in every iteration.
				% when 0 , only a final score is calculated -as [purity,accuracy,score].

if ~exist('single_cov_mat_flag')
    single_cov_mat_flag=1;
end

if ~exist('ClassLabels')
    ClassLabels=[];
end
                
global late_oracle;
if ~exist('late_oracleP')
  late_oracle=1;		% early or late oracle. default is late oracle.
else
  late_oracle=late_oracleP;
end

% handle lack of chunkletts or anti-chunkletts
if ~exist('anti_chunks')
   anti_chunks=[];
end

if ~exist('chunks') | (isempty(chunks))
   chunks=-ones(n,1);
end

if ~exist('calc_gard_num')
   calc_grad_num=0;		% number of times a gradient is calculated per iteration.
end

global aa_flag;	% shared with calculate_partition_function2
if ~exist('aa_flagP')
   aa_flag=1;
else
   aa_flag=aa_flagP;
end
prev_aa_flag= aa_flag;

global reduce_arcs;
if ~exist('reduce_arcsP')
   reduce_arcs=2;
else 
   reduce_arcs=reduce_arcsP;
end

if ~exist('fixed_covmat') % when fixed covmat is set , the covmats aren't updated. param(:,2) is used without change. 
    fixed_covmat=0;
end

if ~exist('small_model_policy')
   small_model_policy=2;
end

% default initialization of the cluster weights


stop_saf=1e-6;		% stopping criterion 
	
% when param is empty :
% several starting conditions are tried and the one with the highest ll is used.
% the score for initial conditions takes into consideration the chunklett information, 
% but not the anti chunklet info.

if isempty(param)
   ch_num=length(unique(chunks))-1;
   nc_inds=find(chunks==-1);   % nc_inds - non chunkletted data indexes
   param=best_params_general(data,param,single_cov_mat_flag,chunks,ch_num,nc_inds);
end

% initialization

global pruned_flag;   
pruned_flag=0;
iteration=1;     % iteration.
global nets;	% the markov nets ( global used in calculate_partition_function2 and in calc_p_and_pll)
global OriginalNets;		% stores the full original nets ( before prunning ) in case 
								% we want to re prune.
original_k=k;	% save for case of model degradation
last_iteration_missed=0;	% a flag indicating whether the last iteration decreased ll
z=[];		% z record ( purity-acuracy scores )
global chunklet_sizes;	% for chunklet pf calculation
global anti_chunk_num;	% for anti chunklet pf aproximation calculation
anti_chunk_num=size(anti_chunks,1);
global anti_chunks_pruned;  % meaningfull only when reduce_arcs==2. the number of pruned negative constraints
anti_chunks_pruned=0;
global exit_flags;	% error messages : details on function remark
exit_flags=0;
global frozen_models;	% used in maximize. a vector containing the indexes of models
								% that were frozed in this session ( not neccesarily that they are frozen now )
frozen_models=[];
remove_models_flag=1;		% if small_model_policy is 1 this variable is 1 for 
                           % the first round, 0 for the other rounds.
grace_turn_flag=0;			% used when small model policy is 2, to indicate the grace turn.
                           
% divide the data into connected components and prepare graphs for each.
[ nets singles nc_inds c_inds oth chunklet_sizes ] = organize_constraints_info(chunks, anti_chunks , k );
OriginalNets=nets;

% start the EM iterations :

while (1)
   % E -step :
   % calculate the probabilities p( hidden i belongs to center j).
      
  
   [probabilities, logLikelihood ]=calc_p_and_pll2(data,param,single_cov_mat_flag,...
                                      c_inds,nc_inds,singles);
                                  
   
   % a calculation of the partition function 
   [ pf stam exp_const ]=calculate_partition_function2(cell2mat(param(:,3)),1,2);
   
   logLikelihood = logLikelihood -log(pf)+ exp_const;
  
   % keeping purity acuracy record
   if (~isempty(ClassLabels)) & (z_record_flag )
      if ~mm_flag
         [ stam , stam , ass ] =calc_ass_and_maxll(data,param,single_cov_mat_flag,c_inds,nc_inds,singles);
      end
      ass=ass(oth);	% from hidden assignment to observable assignment.
      [a2 , b2]=purity_accuracy2(ClassLabels,ass,original_k);
      %visual_k_means(data,ClassLabels,ass);

      z(iteration)=2*a2*b2/(a2+b2);
   end

   if(logLikelihood == -inf)
     z=[-1 -1 -1];
     results=[];
     logLikelihood=[];
     groups=[];
     anti_chunks_pruned=[];
     exit_flags=bitor(exit_flags,8);
     return
 end
   
   % record loglikelihood and check for stop
   ll(iteration)=logLikelihood;
  
   if iteration>1
      if  ( (ll(iteration)-ll(iteration-1))/abs(ll(iteration)) )<stop_saf	% stop condition
         if prev_aa_flag==aa_flag & ~grace_turn_flag	% don't stop if aa_flag has been cancelled this round. ( see in aproxWeights )
            break;
         else
            'grace turn saved me'
         end
      end
   end
         
   iteration=iteration+1;
   prev_param=param;			% save it for case of last terrible round. 
   prev_aa_flag=aa_flag;	% save it to compare and see if aa_flag has been turned off.
   
   % calculate the new parameters.
   param=maximize(data,k,param,probabilities,oth,single_cov_mat_flag,calc_grad_num,...
      fixed_covmat,remove_models_flag);
  
   if small_model_policy==2 & size(param,1)~=k	& iteration>2 % a model has been removed - give grace turn
      grace_turn_flag=1;
   else
      grace_turn_flag=0;
   end
        
   k=size(param,1);	% update the number of models ( models might have been removed ) 
   
   if iteration==2	% after the first iteration, models can be freezed
      if small_model_policy==1
         remove_models_flag=0;	% in itrations >=2 no models are removed.
      end
   end
   
   % change noam 23.6
   if isempty(param) % meaning: maximize has deleted all models
     z=[-1 -1 -1];
     results=[];
     logLikelihood=[];
     groups=[];
     anti_chunks_pruned=[];
     exit_flags=bitor(exit_flags,8);
     return
   end
   %%%% end change noam 23.6
end


% handling terrible bug ( which is expected at this version )
if ll(end)<ll(end-1)		 % the last iteration decreased ll 
   disp( sprintf('last iteration decreased ll from %d to %d \n',ll(end-1),ll(end) ));
   exit_flags=bitor(exit_flags,1);
   ll=ll(1:end-1);
   if z_record_flag
      z=z(1:end-1);
   end
   param=prev_param;
   last_iteration_missed=1;
end


% last prepare the outputs : 

logLikelihood=ll;
results=param;

if (~z_record_flag) | (last_iteration_missed)	% need to caculate the final assignment
   [ stam , stam , groups ] =calc_ass_and_maxll(data,param,single_cov_mat_flag,c_inds,nc_inds,singles);
   groups=groups(oth);	 % from hidden assignment to observable assignment.
else
   groups=ass;
end

if (~isempty(ClassLabels)) & (~z_record_flag)		% calculate groups.
   z=zeros(3,1); % z(1)=purity %z(2)=accuracy z(3)=score 
  [purity , accuracy]=purity_accuracy2(ClassLabels,groups,original_k);
  z(1)=purity;
  z(2)=accuracy;
  z(3)=2*purity*accuracy/(purity+accuracy);
end




