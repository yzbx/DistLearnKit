%this does not rely on pots, only on alphas but should be updated to handle weights in cases of
%late orcale or negative constraints. The alphas should be raised to the power of W's.

function [ pf ,  gpf , exp_const]=calculate_partition_function2(p,no_grad_flag,stage)
% p - the current parameters .
% no_grad_flag  - when set the gradient isn't caculated and the caculation time reduces by factor of 3*k
% impotant input parameters passed as globals are stage and late_oracle.
% stage - if stage==1 only chunklet pf is calculated ( used only in late oracle model )
%			 if stage==2 the full pf is calculated 
% aa_flag - when set , a rude aproximation to anti chunklets pf is used. it is passed
%				as global , not parameter.

% pf - the partition function  
% gpf - the partition function gradient
% exp_const - both pf and gpf should be multiplied by exp(log_const) to get the real value.

global nets;
% nets - a set of connected components of a graph as output by organize_constraints
% nets isn't passed as a parameter because line search who calls this function
% can only send 1 parameter. so nets is passed as a global.the same reason applies
% to late_oracle more.
global late_oracle;
global chunklet_sizes;
global anti_chunk_num;
global aa_flag;

if nargin==1		% default is full pf calculation with gradient
   no_grad_flag=0;
   stage=2;
elseif nargin==2
   stage=2;
end

underflow_line=1e-100;
exp_const=0;
% anti chunklett part of pf.

ln=length(nets);
k=length(p);
pf=1;
gpf=zeros(1,k);

if stage==2		% anti-chunklets pf calculation
   if ~aa_flag
      for i=1:ln
         [cur_pf , cur_gpf ]=connected_component_pf(nets{i}.engine.mnet,nets{i}.engine.elim_order,p,no_grad_flag);
         if no_grad_flag==0
            gpf=cur_gpf*pf+cur_pf*gpf;
         end
         pf=pf*cur_pf;
         
         % underflow considerations
         if no_grad_flag & pf<underflow_line
            exp_const=exp_const+log(pf);
            pf=1;
         elseif (~no_grad_flag) & ( min([pf gpf])<underflow_line	)% underflow protection
            const=min([pf gpf ]);
            exp_const=exp_const+log(const);
            pf=pf/const;
            gpf=gpf/const;
            
         end
      end
   else 		% aproximate the anti chunklet pf ( and grad )
      pf=1;
      if ~no_grad_flag
         gpf=-2*p*anti_chunk_num/(1-sum(p.^2));
      end
      exp_const=anti_chunk_num*log(1-sum(p.^2));
   end
end



% chunklett part of pf
if late_oracle
   cpf=1;
   log_cpf=0;	% log of chunklets pf initialized to 0 (cpf=1)
   cgpf=zeros(1,k);	% chunklets gradient of pf
   for i=1:size(chunklet_sizes,1)	% calculate log of chunklets pf
      log_cpf=log_cpf+chunklet_sizes(i,2)*log( sum(p.^chunklet_sizes(i,1)) );
   end
   exp_const=exp_const+log_cpf;	% unify with anti chunklet pf.
   if no_grad_flag==0
      for i=1:size(chunklet_sizes,1)
         cgpf=cgpf+ chunklet_sizes(i,1)*chunklet_sizes(i,2)/sum(p.^chunklet_sizes(i,1)) ...
            * p.^( chunklet_sizes(i,1)-1 );
      end
      gpf=cgpf*pf+cpf*gpf;	% unify with the anti chunklet pf gradient
   end
end

exp_const=-exp_const;

% older version of chunklet pf, without log-ing all ( underflow danger )
% kept here just for some readability it adds

%% chunklett part of pf
%if late_oracle
%   cpf=1;	% chunklets pf
%   cgpf=zeros(1,k);	% chunklets gradient of pf
%   for i=1:size(chunklet_sizes,1)
%      cpf=cpf* ( sum(p.^chunklet_sizes(i,1))^chunklet_sizes(i,2) );
%   end
%   if no_grad_flag==0
%      for i=1:size(chunklet_sizes,1)
%         cgpf=cgpf+ chunklet_sizes(i,1)*chunklet_sizes(i,2)/sum(p.^chunklet_sizes(i,1)) ...
%            * p.^( chunklet_sizes(i,1)-1 );
%      end
%      cgpf=cgpf*cpf;
%      gpf=cgpf*pf+cpf*gpf;	% unify with the anti chunklet pf gradient
%   end
%   pf=pf*cpf;	% unify with anti chunklet pf.
%end
%
%end
