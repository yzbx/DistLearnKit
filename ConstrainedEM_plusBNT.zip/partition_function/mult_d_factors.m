function [ fac , gfac ]=mult_d_factors(factors,d_factors,no_grad_flag);
% fac gfac - the multiplication result and it's gradient 
% a gradient factor is a struct of k factors : one for the gradient with respect to each p(i)

n=length(factors);
k=size(d_factors,2);
fac=factors(1);
if ~no_grad_flag
   gfac=d_factors(1,:);
else
   gfac=[];
end

if nargin==2 
   no_grad_flag==0
end

for i=2:n
   if no_grad_flag==0
      for j=1:k
          % gfac{j}=add_pots( multiply_pots( factors(i) ,gfac{j} ) , multiply_pots( d_factors{i,j} , fac ) );
          a=multiply_pots( factors(i) ,gfac{j} ) ;
          b=multiply_pots( d_factors{i,j} , fac );
          ez=get_fields(a,'domain');
          gfac{j}=dpot(ez,k*ones(1,length(ez)),get_fields(a,'table')+get_fields(b,'table'));
      end
   end
   fac=multiply_pots( fac,factors(i));
end


