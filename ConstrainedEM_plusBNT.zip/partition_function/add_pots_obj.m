function res=add_pots(pot1, pot2 )
% assumes domain of both pot1 and pot2 are identical
res=dpot(pot1.domain,pot1.sizes,pot1.T+pot2.T);

