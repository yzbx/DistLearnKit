
ANTI_CHUNK_HOME = pwd;

files = {'EM','mnet_jtree', 'Mstep', 'partition_function', ...
      'spanning_tree', 'BNT_components' };

for i=1:length(files)
  f = files{i};
  eval(sprintf('addpath ''%s''/%s', ANTI_CHUNK_HOME, f));
end

