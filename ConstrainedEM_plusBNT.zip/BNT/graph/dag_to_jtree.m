function [jtree, root, cliques, B, w] = dag_to_jtree(bnet, obs_nodes, stages, clusters)
% DAG_TO_JTREE Moralize and triangulate a DAG, and make a junction tree from its cliques.
% [jtree, root, cliques, B, w] = dag_to_jtree(bnet, obs_nodes, stages, clusters)
%
% jtree(i,j) = 1 iff there is an arc between clique i and clique j 
% root = the root clique
% cliques{i} = the nodes in clique i
% B(i,j) = 1 iff node j occurs in clique i
% w(i) = weight of clique i


N = length(bnet.dag);
[MG, moral_edges]  = moralize(bnet.dag);

% Add extra arcs between nodes in each cluster to ensure they occur in the same clique
for i=1:length(clusters)
  c = clusters{i};
  MG(c,c) = 1;
end
MG = setdiag(MG, 0);

% Find an optimal elimination ordering (NP-hard problem!)
ns = bnet.node_sizes(:);
ns(obs_nodes) = 1; % observed nodes have only 1 possible value
partial_order = determine_elim_constraints(bnet, obs_nodes);

if isempty(partial_order)
  elim_order = best_first_elim_order(MG, ns, stages);
else
  elim_order = strong_elim_order(MG, ns, partial_order);
end

%disp('elim order');
%elim_order

[MTG, cliques, fill_in_edges]  = triangulate(MG, elim_order);
%fill_in_edges

% Connect the cliques up into a jtree,
if isempty(partial_order)
  [jtree, root, B, w] = cliques_to_jtree(cliques, ns);
else
  disp('using strong triangulation');
  [jtree, root, cliques, B, w] = cliques_to_strong_jtree(cliques, ns, elim_order, MTG);
end

if 0
  disp('testing dag to jtree');
  % Find the cliques containing each node, and check they form a connected subtree
  clqs_con_node = cell(1,N);
  for i=1:N
    clqs_con_node{i} = find(B(:,i))';
  end
  check_jtree_property(clqs_con_node, jtree);
end
