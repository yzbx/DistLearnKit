data = [0     0;
	0.01  0.01;
	0.5   0;
	1.1   0.5;
	2     1;
	3     10];

for i=1:size(data,1)
  counts = data(i,:);
  for Z=-10:2
    a=entropic_map(counts, Z);
    b=entropic_map_estimate(counts, Z);
    if ~approxeq(a,b)
      fprintf('unequal at Z=%d\n', Z);
      counts
      a
      b
    end
  end
end
