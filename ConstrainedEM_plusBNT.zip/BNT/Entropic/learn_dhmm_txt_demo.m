ntrain = 2;
ntest = 2;
[data, textlines, O] = read_ap_txt('ap88.txt', ntest+ntrain);

train_data = data(1:ntrain);
test_data = data(ntrain+1:ntrain+ntest);

Q = 10;
hmm1 = mk_rnd_dhmm(Q, O);
[hmm2, LL] = learn_dhmm_simple(train_data, hmm1, 'dirichlet', 1);
%[hmm3, LL] = learn_dhmm_entropic(train_data, hmm1, 'dirichlet', 1);

loglik1 = log_lik_dhmm(test_data, hmm1.prior, hmm1.transmat, hmm1.obsmat)
loglik2 = log_lik_dhmm(test_data, hmm2.prior, hmm2.transmat, hmm2.obsmat)
