/* 
   function x = loglambertwn1(y)
*/

#define FUNCTION loglambertwn1
#include "lambert.c"
