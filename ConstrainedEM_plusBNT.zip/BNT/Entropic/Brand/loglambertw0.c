/* 
   function x = loglambertw0(y)
*/

#define FUNCTION loglambertw0
#include "lambert.c"
