/*
   function x = lambertw0(y)
*/
  
#define FUNCTION lambertw0
#include "lambert.c"
