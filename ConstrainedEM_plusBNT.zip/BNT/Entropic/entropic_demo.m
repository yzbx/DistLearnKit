hmm0 = mk_dhmm_ex0;

ntrain = 20;
ntest = 5;

[data, hidden] = sample_dhmm_endstate(hmm0.startprob, hmm0.transmat, hmm0.obsmat, hmm0.endprob, ntrain + ntest);

train_data = data(1:ntrain);
test_data = data(ntrain+1:ntrain+ntest);

hmm = {};

% hmm{1} is the starting point for learning
% hmm{1} = hmm0;
hmm{1} = mk_rnd_dhmm(hmm0.nstates, hmm0.nobs);
%hmm{1} = mk_rnd_dhmm(hmm0.nstates+1, hmm0.nobs); % more states than necessary

[hmm{2}, LL] = learn_dhmm_simple(train_data, hmm{1});
[hmm{3}, LL] = learn_dhmm_entropic(train_data, hmm{1});
[hmm{4}, LL] = learn_dhmm_entropic(train_data, hmm{1}, 'trimtrans', 1, 'trimobs', 1);
[hmm{5}, LL] = learn_dhmm_entropic(train_data, hmm{1}, 'anneal', 1);
[hmm{6}, LL] = learn_dhmm_entropic(train_data, hmm{1}, 'trimtrans', 1, 'trimobs', 1, 'anneal', 1);

for i=1:length(hmm)
  loglik = log_lik_dhmm(test_data, hmm{i}.prior, hmm{i}.transmat, hmm{i}.obsmat)
end
