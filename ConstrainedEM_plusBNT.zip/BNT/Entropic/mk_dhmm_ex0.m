function hmm = mk_dhmm_ex1()

% generate strings of the form 1(23)+4
%      / --\
% 1 -> 2 -> 3 -> 4 

hmm.nstates = 4;
hmm.nobs = 4;
hmm.type = 'discrete';

hmm.startprob = [1 0 0 0];
hmm.endprob = [0 0 0 1];

hmm.transmat = [0.0 1.0 0.0 0.0
	    0.0 0.0 1.0 0.0
	    0.0 0.5 0.0 0.5
	    0.0 0.0 0.0 0.0];

hmm.obsmat = eye(4);

