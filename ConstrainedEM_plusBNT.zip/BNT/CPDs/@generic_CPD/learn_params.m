function CPD = compute_MLE(CPD, fam, data, ns, cnodes)
% COMPUTE_MLE Compute the maximum likelihood estimate of the params of a generic CPD given complete data
% CPD = compute_MLE(CPD, fam, data, ns, cnodes)
%
% data(i,m) is the value of node i in case m (can be cell array).
% We assume this node has a maximize_params method.

ncases = size(data, 2);
CPD = reset_ess(CPD);
% make a fully observed joint distribution over the family
fmarginal.domain = fam;
fmarginal.T = 1;
fmarginal.mu = [];
fmarginal.Sigma = [];
if ~iscell(data)
  cases = num2cell(data);
else
  cases = data;
end
for m=1:ncases
  CPD = update_ess(CPD, fmarginal, cases(:,m), ns, cnodes);
end
CPD = maximize_params(CPD);
