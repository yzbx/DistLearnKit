function CPD = mk_isolated_tabular_CPD(ps, fam_sz, args)
% function CPD = mk_isolated_tabular_CPD(ps, fam_sz, args)
% make a mini-bnet containing just this one family, because we can't create
% free-standing CPD objects


n = length(ps)+1;
self = n;
dag = zeros(n);
ps = 1:(n-1);
if ~isempty(ps)
  dag(ps,n) = 1;
end
bnet = mk_bnet(dag, fam_sz);
CPD = tabular_CPD(bnet, n, args{:});
