global BNT_HOME

cd(sprintf('%s/potentials/@dpot', BNT_HOME))
mex multiply_by_pot.c
mex divide_by_pot.c

cd(sprintf('%s/potentials/Tables', BNT_HOME))
mex marg_table.c % used by @dpot/marginalize_pot.m
mex mult_by_table.c

mex mk_ndxB.c 
mex mult_by_table_ndxB.c
mex divide_by_table_ndxB.c
mex marg_table_ndxB.c

mex mult_by_table_ndxSD.c
mex divide_by_table_ndxSD.c
mex marg_table_ndxSD.c

mex mult_by_table_ndxD.c
mex divide_by_table_ndxD.c
mex marg_table_ndxD.c

mex rep_mult.c

cd(sprintf('%s/misc', BNT_HOME))
mex ind2subv.c
mex subv2ind.c
mex normalise.c

cd(sprintf('%s/inference/static/@jtree_ndx_inf_engine', BNT_HOME))
mex init_pot.c
mex collect_evidence.c
mex distribute_evidence.c

cd(sprintf('%s/inference/static/@jtree_C_inf_engine', BNT_HOME))
mex init_pot.c
mex collect_evidence.c
mex distribute_evidence.c

cd(sprintf('%s/inference/static/@gibbs_sampling_inf_engine/private', BNT_HOME))
mex compute_posterior.c
mex get_slice_dbn.c
mex sample_single_discrete.c


cd(sprintf('%s/Entropic/Brand', BNT_HOME))
mex lambertw0.c
mex lambertwn1.c
mex loglambertw0.c
mex loglambertwn1.c

% C routines needed by best_first_elim_order, strong_elim_order, and triangulate
dir = fullfile(BNT_HOME, 'graph/C');
cd(dir);

if 0
if isunix
  mex -c elim.c;
  mex -c cell.c;
  mex -c map.c;
  mex -DUNIX  best_first_elim_order.c  elim.o  cell.o  map.o;
  mex -DUNIX  triangulate.c  elim.o  cell.o  map.o;
else
  % in Windows ...
  mex -c elim.c;
  mex -c cell.c;
  mex -c map.c;
  mex  best_first_elim_order.c  elim.obj  cell.obj  map.obj;
  mex  triangulate.c  elim.obj  cell.obj  map.obj;
end
end
