The Bayes Net Toolbox for Matlab was written by Kevin Patrick Murphy et al.
This version was last updated on 1 April 2002.
To download the latest version, and to get documentation, please go to
   http://www.cs.berkeley.edu/~murphyk/Bayes/bnt.html
