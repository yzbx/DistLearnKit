function bnet = mk_hhmm2(varargin)
% MK_HHMM2 Make a 2 level Hierarchical HMM
% bnet = mk_hhmm2(...)
%
% 2-layer hierarchical HMM 
%
%   Q1 --------->    Q1
% /  | \            / |
% |  |  v          /  |
% |  |  F2 --- /   |
% |  |  ^         \   |
% |  | /           \  |
% |  v              \ v
% |  Q2  -------->   Q2 
% |  |    
% \  | 
%  v v    
%   O
%
%
% Q1 (slice 1) is clamped to be uniform.
% Q2 (slice 1) is clamped to always start in state 1.
% F2 by default will only finish if Q2 is in its last state, and then only with prob 0.5 (call this the F2CPT)
% Q1/Q2 (slice 2) by default gets the default hhmm_CPD params.
% O by default gets the default tabular/Gaussian params.
%
% Optional arguments in name/value format [default]
%
% Qsizes      - sizes at each level [ none ]
% Osize       - size of O node [ none ]
% discrete_obs - 1 means O is tabular_CPD, 0 means O is gaussian_CPD [0]
% Oargs       - cell array of args to pass to the O CPD  [ {} ]
% Q1args      - args to be passed to constructor for Q1 (slice 2) [ {} ]
% Q2args      - args to be passed to constructor for Q2 (slice 2) [ {} ]
% Fargs       - args to be passed to constructor for F2 [ {'CPT', F2CPT} ]
% F2toQ1       -  1 means F2->Q1 is present so Q2 is an hhmm_CPD, 0 means arc is absent, so level 2 never resets [1]
%

% get sizes of nodes
args = varargin;
nargs = length(args);
Qsizes = [];
Osize = 0;
for i=1:2:nargs
  switch args{i},
   case 'Qsizes', Qsizes = args{i+1}; 
   case 'Osize', Osize = args{i+1}; 
  end
end
if isempty(Qsizes), error('must specify Qsizes'); end
if Osize==0, error('must specify Osize'); end
  
% set default params
discrete_obs = 0;
Oargs = {};
Q1args = {};
Q2args = {};
F2toQ1 = 1;

% P(Q1, Q2, F2)
CPT = zeros(Qsizes(1), Qsizes(2), 2);
% Each model can only terminate in its final state.
% 0 params will remain 0 during EM, thus enforcing this constraint.
CPT(:, :, 1) = 1.0; % all states turn F off ...
p = 0.5;
CPT(:, Qsizes(2), 2) = p; % except the last one
CPT(:, Qsizes(2), 1) = 1-p;
Fargs = {'CPT', CPT};

for i=1:2:nargs
  switch args{i},
   case 'discrete_obs', discrete_obs = args{i+1}; 
   case 'Oargs',        Oargs = args{i+1};
   case 'Q1args',       Q1args = args{i+1};
   case 'Q2args',       Q2args = args{i+1};
   case 'F2toQ1',       F2toQ1 = args{i+1}; 
   otherwise, error(['unrecognized argument ' args{i}])
  end
end

ss = 4;
Q1 = 1; Q2 = 2; F2 = 3; obs = 4;
Qnodes = [Q1 Q2];
names = {'Q1', 'Q2', 'F2', 'obs'};
intra = zeros(ss);
intra(Q1, [Q2 F2 obs]) = 1;
intra(Q2, [F2 obs]) = 1;

inter = zeros(ss);
inter(Q1,Q1) = 1;
inter(F2,Q1) = 1;
if F2toQ2
  inter(F2,Q2)=1;
end
inter(Q2,Q2) = 1;

ns = zeros(1,ss);
ns(Qnodes) = Qsizes;
ns(obs) = Osize;
ns(F2) = 2;

dnodes = [Q1 Q2 F2];
if discrete_obs
  dnodes = [dnodes obs];
end
onodes = [obs];

bnet = mk_dbn(intra, inter, ns, 'observed', onodes, 'discrete', dnodes, 'names', names);
eclass = bnet.equiv_class;

% SLICE 1

% We clamp untied nodes in the first slice, since their params can't be estimated
% from just one sequence

% uniform prior on initial model
CPT = normalise(ones(1,ns(Q1)));
bnet.CPD{eclass(Q1,1)} = tabular_CPD(bnet, Q1, 'CPT', CPT, 'adjustable', 0);

% each model always starts in state 1
CPT = zeros(ns(Q1), ns(Q2));
CPT(:, 1) = 1.0;
bnet.CPD{eclass(Q2,1)} = tabular_CPD(bnet, Q2, 'CPT', CPT, 'adjustable', 0);

bnet.CPD{eclass(F2,1)}  = tabular_CPD(bnet, F2, F2args{:});

if discrete_obs
  bnet.CPD{eclass(obs,1)} = tabular_CPD(bnet, obs, Oargs{:});
else
  bnet.CPD{eclass(obs,1)} = gaussian_CPD(bnet, obs, Oargs{:});
end

% SLICE 2

bnet.CPD{eclass(Q1,2)} = hhmm_CPD(bnet, Q1+ss, Qnodes, 1, D, 'args', Q1args);

if F2toQ2
  bnet.CPD{eclass(Q2,2)} = hhmmQ_CPD(bnet, Q2+ss, Qnodes, 2, D, 'args', Q2args);
else
  bnet.CPD{eclass(Q2,2)} = tabular_CPD(bnet, Q2+ss, Q2args{:});
end
