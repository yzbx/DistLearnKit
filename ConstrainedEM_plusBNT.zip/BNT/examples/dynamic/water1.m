% Compare the speeds of various inference engines on the water DBN
seed = 0;
rand('state', seed);
randn('state', seed);

bnet = mk_water_dbn;

T = 3;
USEC = exist('@jtree_C_inf_engine/collect_evidence','file');

engine = {};
engine{end+1} = smoother_engine(jtree_2TBN_inf_engine(bnet));
engine{end+1} = smoother_engine(hmm_2TBN_inf_engine(bnet));
engine{end+1} = jtree_dbn_inf_engine(bnet);
engine{end+1} = jtree_unrolled_dbn_inf_engine(bnet, T); 
if 1
engine{end+1} = jtree_ndx_dbn_inf_engine(bnet, 'ndx_type', 'SD');
engine{end+1} = jtree_ndx_dbn_inf_engine(bnet, 'ndx_type', 'D');
engine{end+1} = jtree_ndx_dbn_inf_engine(bnet, 'ndx_type', 'B');
if USEC, engine{end+1} = jtree_C_dbn_inf_engine(bnet); end % fails if obs_leaves=0?
%engine{end+1} = hmm_inf_engine(bnet);
end

%engine{end+1} = bk_inf_engine(bnet, 'ff', onodes);
%engine{end+1} = bk_inf_engine(bnet, { [1 2], [3 4 5 6], [7 8] }, onodes);

inf_time = cmp_inference_dbn(bnet, engine, T)
learning_time = cmp_learning_dbn(bnet, engine, T)

