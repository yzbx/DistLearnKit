% Q1 -> Q2
%  \   /
%    Y
% Qi are discrete, Y is cts

n = 3;
dag = zeros(3);
dag(1, [2 3]) = 1;
dag(2, 3) = 1;
ns = [2 2 3];

dnodes = [1 2];
bnet = mk_bnet(dag, ns, dnodes);
bnet.CPD{1} = tabular_CPD(bnet, 1);
bnet.CPD{2} = tabular_CPD(bnet, 2);
bnet.CPD{3} = gaussian_CPD(bnet, 3);

evidence = cell(1,n);
jpot = compute_joint_pot(bnet, 1:n, evidence);
