% This example illustrates how we can build a naive Bayes classifier
% with different kinds of observed leaves.

N = 3;
dag = zeros(N,N);
dag(1,2:N)=1;
dnodes = [1 2];
nclasses = 2;
ns = [nclasses 2 3];
bnet = make_bnet(dag, ns, dnodes);

rand('state', 0);
randn('state', 0);
bnet.CPD{1} = tabular_CPD(bnet, 1);
bnet.CPD{2} = tabular_CPD(bnet, 2);
bnet.CPD{3} = gaussian_CPD(bnet, 3);
%bnet = randomize_params(bnet, 0);

engine = var_elim_inf_engine(bnet);
evidence = cell(1,N);
evidence{2} = 2;
evidence{3} = [-0.1 0.1 0.2]';
query = 1;
m1 = infer(engine, evidence, query);


% Compare with BNT
bnet2 = mk_bnet(dag, ns, dnodes);
rand('state', 0);
randn('state', 0);
bnet2.bnodes{1} = mk_tabular_node(bnet2, 1);
bnet2.bnodes{2} = mk_tabular_node(bnet2, 2);
bnet2.bnodes{3} = mk_gaussian_node(bnet2, 3);
%bnet2 = randomize_params(bnet2, 0);

vals = [2 -0.1 0.1 0.2];
onodes = [2 3];
[bnet2, ll2] = enter_evidence(bnet2, vals, onodes);
m2 = marginal_nodes(bnet2, query);
approxeq(m2.T(:), m1(:))
