
% Make the following network (from Jensen (1996) p84 fig 4.17)
%    1
%  / | \
% 2  3  4
% |  |  |
% 5  6  7
%  \/ \/
%  8   9
% where all arcs point downwards

disp('running gaussian1')

N = 9;
dag = zeros(N,N);
dag(1,2)=1; dag(1,3)=1; dag(1,4)=1;
dag(2,5)=1; dag(3,6)=1; dag(4,7)=1;
dag(5,8)=1; dag(6,8)=1; dag(6,9)=1; dag(7,9) = 1;

ns = [5 4 3 2 2 1 2 2 2]; % vector-valued nodes
%ns = ones(1,9); % scalar nodes
dnodes = [];

bnet = mk_bnet(dag, ns, 'discrete', []);
rand('state', 0);
randn('state', 0);
for i=1:N
  %bnet.CPD{i} = gaussian_CPD(bnet, i, [], [], [], 'diag');
  bnet.CPD{i} = gaussian_CPD(bnet, i);
end


clear engine;
engine{1} = gaussian_inf_engine(bnet);
engine{2} = jtree_inf_engine(bnet);

nengines = length(engine);
m = cell(1, nengines);
ll = zeros(1, nengines);


evidence = cell(1,N);
evidence{5} = rand(ns(5),1);
evidence{4} = rand(ns(4),1);

% Try a query on 2 nodes simultaneously but excluding any observed nodes
query = [1];

for i=1:nengines
  [engine{i}, ll(i)] = enter_evidence(engine{i}, evidence);
  m{i} = marginal_nodes(engine{i}, query);
end

% compare all engines to engine{1}
for i=2:nengines
  assert(approxeq(m{1}.mu, m{i}.mu));
  assert(approxeq(m{1}.Sigma, m{i}.Sigma));
  assert(approxeq(ll(1), ll(i)));
end


% Try a query on 2 nodes simultaneously but including the observed nodes
query = [5 6 8];

for i=1:nengines
  m{i} = marginal_nodes(engine{i}, query);
end

% compare all engines to engine{1}
for i=2:nengines
  assert(approxeq(m{1}.mu, m{i}.mu));
  assert(approxeq(m{1}.Sigma, m{i}.Sigma));
  assert(approxeq(ll(1), ll(i)));
end




