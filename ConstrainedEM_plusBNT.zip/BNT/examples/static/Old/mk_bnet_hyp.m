function [hyp_bnet, prior] = mk_bnet_hyp(hyp_G, ns)
% MK_BNET_HYP Make bnets (with tabular nodes and unif. params) out of each possible graph structure
% [hyp_bnet, prior] = mk_bnet_hyp(hyp_G, ns)

nhyp = size(hyp_G, 3);
N = size(hyp_G, 1);

hyp_bnet = cell(1, nhyp);
for i=1:nhyp
  hyp_bnet{i} = mk_bnet(hyp_G(:,:,i), ns);
  for j=1:N
    hyp_bnet{i}.CPD{j} = tabular_CPD(hyp_bnet{i}, j, 'unif', 1);
  end
end
prior = normalise(ones(1, nhyp));
