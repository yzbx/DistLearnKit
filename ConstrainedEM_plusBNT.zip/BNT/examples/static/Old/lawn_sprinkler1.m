% See www.cs.berkeley.edu/~murphyk/Bayes/usage.html for details.

N = 4; 
dag = zeros(N,N);
dag(1,2) = 1; dag(1,3) = 1; dag(2,4) = 1; dag(3,4) = 1;
ns = 2*ones(1,N);
bnet = make_bnet(dag, ns);

bnet.CPD{1} = tabular_CPD(bnet, 1, [0.5 0.5]);
bnet.CPD{2} = tabular_CPD(bnet, 2, [0.8 0.2 0.2 0.8]);
bnet.CPD{3} = tabular_CPD(bnet, 3, [0.5 0.9 0.5 0.1]);
bnet.CPD{4} = tabular_CPD(bnet, 4, [1 0.1 0.1 0.01 0 0.9 0.9 0.99]);

evidence = cell(1,N);
evidence{2} = 2;
query = [2 3 4];

% Enumeration
engine1 = enumerative_inf_engine(bnet);
[m1, ll1] = infer(engine1, evidence, query);
%p1 = m1.T(2)
%assert(approxeq(p1, 0.4298))

% variable elimination
engine2 = var_elim_inf_engine(bnet);
[m2, ll2] = infer(engine2, evidence, query);
approxeq(m1.T, m2.T)
approxeq(ll1, ll2)

% jtree
engine3 = jtree_inf_engine(bnet);
[marginals3, fmarginals3, ll3] = infer(engine3, evidence);
m3 = marginals3{query};
approxeq(m1.T(:), m3.T(:))
approxeq(ll1, ll3)



% BNT
bnet0 = mk_bnet(dag, ns);
for i=1:N
  bnet0.bnodes{i} = mk_tabular_node(bnet0,i);
end
bnet0.bnodes{1}.CPT(:) = [0.5 0.5];
bnet0.bnodes{2}.CPT(:) = [0.8 0.2 0.2 0.8];
bnet0.bnodes{3}.CPT(:) = [0.5 0.9 0.5 0.1];
bnet0.bnodes{4}.CPT(:) = [1 0.1 0.1 0.01 0 0.9 0.9 0.99];
obs_nodes = [4];
vals = [2];
[bnet0, ll0] = enter_evidence(bnet0, vals, obs_nodes);
m0 = marginal_nodes(bnet0, query);
approxeq(m0.T, m1.T)
approxeq(ll0, ll1)   


% marginal on hidden and observed nodes
query = [3 4];
% since node 4 is instantiated to 2,
% m1(x3,x4) will be 0s except where x4 = 2
[m1, ll1] = infer(engine1, evidence, query);
[m2, ll2] = infer(engine2, evidence, query);
assert(approxeq(m1.T, m2.T))
m0 = marginal_nodes(bnet0, query);
assert(approxeq(m1.T, m0.T))

