% Compare various inference engines on the following network (from Jensen (1996) p84 fig 4.17)
%    1
%  / | \
% 2  3  4
% |  |  |
% 5  6  7
%  \/ \/
%  8   9
% where all arcs point downwards
rand('state', 0);
randn('state', 0);

N = 9;
dag = zeros(N,N);
dag(1,2)=1; dag(1,3)=1; dag(1,4)=1;
dag(2,5)=1; dag(3,6)=1; dag(4,7)=1;
dag(5,8)=1; dag(6,8)=1; dag(6,9)=1; dag(7,9) = 1;

dnodes = 1:N;
false = 1; true = 2;
ns = 2*ones(1,N); % binary nodes

bnet = mk_bnet(dag, ns);
% use random params
for i=1:N
  bnet.CPD{i} = tabular_CPD(bnet, i);
end

onodes = [2 7];
query = [3 6];
%query = [1 9];
engine = {};
clusters = {query};
engine{end+1} = jtree_inf_engine(bnet, 'observed', onodes, 'clusters', clusters, 'use_ndx', 1);
engine{end+1} = jtree_inf_engine(bnet, 'observed', onodes, 'clusters', clusters);
engine{end+1} = jtree_C_inf_engine(bnet, 'observed', onodes, 'clusters', clusters);
nengines = length(engine);


m = cell(1, nengines);
ll = zeros(1, nengines);

evidence = cell(1,N);
evidence(onodes) = num2cell([1 2]);

for i=1:nengines
  fprintf('calling enter_evidence for engine %d\n', i);
  [engine{i}, ll(i)] = enter_evidence(engine{i}, evidence);
end

% compare all engines to engine{1}
ll

for i=2:nengines
  assert(approxeq(ll(1), ll(i)));
end


for i=1:nengines
  fprintf('calling marginal_nodes for engine %d\n', i);
  m{i} = marginal_nodes(engine{i}, query);
end
for i=2:nengines
  assert(approxeq(m{1}.T, m{i}.T));
end

disp('finished discrete2');
