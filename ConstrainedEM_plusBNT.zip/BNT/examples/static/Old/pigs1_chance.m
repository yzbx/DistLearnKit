% make the reactive policy pigs model (fig 2 from Lauritzen and Nilsson, 2001)

% we number nodes down and to the right
h = [1 5 9 13];
t = [2 6 10];
d = [3 7 11];
u = [4 8 12 14];

N = 14;
dag = zeros(N);
for i=1:3
  dag(h(i), [t(i) h(i+1)]) = 1;
  dag(t(i), d(i)) = 1;
  dag(d(i), [u(i) h(i+1)]) = 1;
end
dag(h(4), u(4)) = 1;

hsz = 2; tsz = 2; dsz = 2; 
ns = 2*ones(1,N);
ns(u) = 1;

% parameter tying
params = ones(1,N);
uparam = 1;
final_uparam = 2;
tparam = 3;
h1_param = 4;
hparam = 5;
dparams = 6:8;

params(u(1:3)) = uparam;
params(u(4)) = final_uparam;
params(t) = tparam;
params(h(1)) = h1_param;
params(h(2:end)) = hparam;
params(d) = dparams;

limid = mk_limid(dag, ns, 'chance', [h t], 'decision', d, 'utility', u, 'params', params);

% h = 1 means healthy, h = 2 means diseased
% d = 1 means don't treat, d = 2 means treat
% t = 1 means test shows healthy, t = 2 means test shows diseased

% u4 | h4
limid.CPD{final_uparam} = tabular_utility_node(hsz, [1000 300]);

% ui | di, i=1:3
limid.CPD{uparam} = tabular_utility_node(dsz, [0 100]);

% h  P(t=1) P(t=2)
% 1  0.9   0.1
% 2  0.2   0.8
limid.CPD{tparam} = tabular_chance_node([hsz tsz], [0.9 0.2 0.1 0.8]);

% P(h1)
limid.CPD{h1_param} = tabular_chance_node(hsz, [0.9 0.1]);

% hi di P(hj=1) P(hj=2),  j = i+1, i=1:3
% 1  1  0.8     0.2
% 2  1  0.1     0.9
% 1  2  0.9     0.1
% 2  2  0.5     0.5
limid.CPD{hparam} = tabular_chance_node([hsz dsz hsz], [0.8 0.1 0.9 0.5 0.2 0.9 0.1 0.5]);

% P(di | ti) = initially uniform 
for i=1:3
  limid.CPD{dparams(i)} = tabular_decision_node([tsz dsz]);
end



clear engines;
engines{1} = naive_meu_engine(limid);
engines{2} = jtree_meu_engine(limid);

for e=1:length(engines)
  [strategy{e}, MEU(e)] = solve_limid(engines{e});
end

