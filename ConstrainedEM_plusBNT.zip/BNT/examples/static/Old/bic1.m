% compare BIC and Bayesian score 

N = 4;
dag = zeros(N,N);
%C = 1; S = 2; R = 3; W = 4; % topological order
C = 4; S = 2; R = 3; W = 1; % arbitrary order
dag(C,[R S]) = 1;
dag(R,W) = 1;
dag(S,W)=1;


false = 1; true = 2;
ns = 2*ones(1,N); % binary nodes
bnet = mk_bnet(dag, ns);
bnet.CPD{C} = tabular_CPD(bnet, C, [0.5 0.5]);
bnet.CPD{R} = tabular_CPD(bnet, R, [0.8 0.2 0.2 0.8]);
bnet.CPD{S} = tabular_CPD(bnet, S, [0.5 0.9 0.5 0.1]);
bnet.CPD{W} = tabular_CPD(bnet, W, [1 0.1 0.1 0.01 0 0.9 0.9 0.99]);


seed = 0;
rand('state', seed);
randn('state', seed);
ncases = 1000;
usecell = 0;
data = sample_bnet(bnet, ncases, usecell);


%sz = 1:100:1000;
sz = 1:20;
S = length(sz);
bic_score = zeros(1, S);
bayes_score = zeros(1, S);
for i=1:S
  bic_score(i) = score_dags(data(:,1:sz(i)), ns, {dag}, 'scoring_fn', 'bic', 'params', []);
  bayes_score(i) = score_dags(data(:,1:sz(i)), ns, {dag});
end

plot(sz, bic_score, 'r-o',  sz, bayes_score, 'g--*')
xlabel('num. data cases')
ylabel('score')
legend('bic', 'bayes')
title('score vs. size of data set')

%previewfig(gcf, 'format', 'png', 'height', 2, 'color', 'rgb')
%exportfig(gcf, '/home/cs/murphyk/public_html/Bayes/Figures/bic.png', 'format', 'png', 'height', 2, 'color', 'rgb')
