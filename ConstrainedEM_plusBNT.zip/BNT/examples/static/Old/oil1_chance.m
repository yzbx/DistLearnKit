% oil wildcatter influence diagram in Cowell et al p172

T = 1; UT = 2; O = 3; R = 4; D = 5; UD = 6;
N = 6;
dag = zeros(N);
dag(T, [UT R D]) = 1;
dag(O, [R UD]) = 1;
dag(R, D) = 1;
dag(D, UD) = 1;

ns = zeros(1,N);
ns(O) = 3; ns(R) = 4; ns(T) = 2; ns(D) = 2; ns(UT) = 1; ns(UD) = 1;

limid = mk_limid(dag, ns, 'chance', [O R], 'decision', [T D], 'utility', [UT UD]);

limid.CPD{O} = tabular_chance_node(ns(O), [0.5 0.3 0.2]);
tbl = [0.6 0 0.3 0 0.1 0  0.3 0 0.4 0 0.4 0  0.1 0 0.3 0 0.5 0  0 1 0 1 0 1];
limid.CPD{R} = tabular_chance_node(ns([T O R]), tbl);

limid.CPD{UT} = tabular_utility_node(ns(T), [-10 0]);
limid.CPD{UD} = tabular_utility_node(ns([O D]), [-70 50 200  0 0 0]);

if 1
  % start with uniform policies
  limid.CPD{T} = tabular_decision_node(ns(T));
  limid.CPD{D} = tabular_decision_node(ns([T R D]));
else
  % hard code optimal policies
  limid.CPD{T} = tabular_decision_node(ns(T), [1.0 0.0]);        
  a = 0.5; b = 1-a; % arbitrary value
  tbl = myreshape([0 a 1 a 1 a a a  1 b 0 b 0 b b b], ns([T R D]));
  limid.CPD{D} = tabular_decision_node(ns([T R D]), tbl);
end


%[strategy, MEU] = solve_limid_naive(limid);

clear engines;
engines{1} = naive_meu_engine(limid);
engines{2} = jtree_meu_engine(limid);

for e=1:length(engines)
  [strategy, MEU] = solve_limid(engines{e});
  
  assert(approxeq(MEU, 22.5))
  assert(argmax(strategy{T} == 1)); % test = yes
  t = 1; % test = yes
  for r=[2 3] % OpS, ClS
    assert(argmax(squeeze(strategy{D}(t,r,:))) == 1); % drill = yes
  end
  r = 1; % noS
  assert(argmax(squeeze(strategy{D}(t,r,:))) == 2); % drill = no
end

 
