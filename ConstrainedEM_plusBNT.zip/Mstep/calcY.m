%calculate the current Y value of the function to be minimized.

function [currY]= calcY(coefficient)
global naiveWeights;
global Alphas;
global gradientY;
global stage;
%load params;

newAlphas= Alphas + coefficient*gradientY;
[currZ stam exp_const ]= calculate_partition_function2(newAlphas,1,stage);

if ~isempty(find(newAlphas==0))
    'w'
end

currY= - ( -log(currZ) + exp_const + naiveWeights*log(newAlphas)');  