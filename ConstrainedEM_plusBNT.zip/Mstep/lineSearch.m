%perform binary line search for the best parameters Alpha using the
%current computed gradient of the funtion Y.

function [newAlphas , fval]= lineSearch(currZ,exp_const,naiveWeightsP,AlphasP,gradientYP)
global naiveWeights;
global Alphas;
global gradientY;
global stage;

if stage==1
   tol=0.001;		% x tolerance for chunklet pf line search
else
   tol=0.01;		% x tolerance for general pf line search
end

%disp('in line search ??????')
% copy parameters into global variables in order to use them in calcY.
naiveWeights=naiveWeightsP;
Alphas=AlphasP;
gradientY=gradientYP;

%compute currrent value of Y. ( for debug )
currY=  -log(currZ) + exp_const + naiveWeights*log(Alphas)';  

low= 0;

[high] = findMaximalGradientCoefficient(Alphas,gradientY);

[x,fval,exitflag,output] = fminbnd('calcY',low,high-tol*high,optimset('TolX',tol*high,'Display','off'));
newAlphas= Alphas+x*gradientY;

% a check for gradient ascent (only for debug )
% currZ=calculate_partition_function2(newAlphas);
% currY=-log(currZ) + naiveWeights*log(newAlphas)';


