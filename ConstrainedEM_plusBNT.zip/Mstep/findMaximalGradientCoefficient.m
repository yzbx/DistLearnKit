% compute maximal gradient coefficient that may be added to Alphas to
% remain in simplex. Used to perform lineSearch.

%params:
% Alphas - current Alphas
% gradientY - the current gradient Direction

%returns:
% maxCoefficient - the maximal coefficient of all alphas to remain in simplex


function [maxCoefficient] =findMaximalGradientCoefficient(Alphas,gradientY)

negInds= find(gradientY < 0);
posInds = find(gradientY >0);

coefficients= zeros(1,length(gradientY));
coefficients(negInds)= -Alphas(negInds)./gradientY(negInds);
coefficients(posInds)= (1-Alphas(posInds))./gradientY(posInds);

maxCoefficient= min(coefficients);


