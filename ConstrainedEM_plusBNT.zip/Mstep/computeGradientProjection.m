
% project gradient - using gradient projection - to remain in simplex!!!


function [projGradientY]= computeGradientProjection(gradientY)


%check if gradientY needs to be projected :
if(sum(gradientY) ~=0)
  
  x= ones(1,length(gradientY));
  x= x./norm(x);
  projGradientY= gradientY - ((gradientY*x')*x);
  
else % no projection needed:
  projGradientY= gradientY;
end

  




