

This package contains a Matlab implementation of he Constrained EM algorithm.

The implementation uses routines from the BNT software package for Bayesian networks, so the BNT is included here.

The BNT is a free code library. It's home page is at http://www.ai.mit.edu/~murphyk/Software/BNT/bnt.html, and you can 
download the newest BNT versions from there. However, the version in this package is all you need in order to run the constrained EM.

This package is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
 of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 




Installing and running :


1. Unzip the package into the target directory.
2. Activate Matlab and enter the target directory.
3. Run the script 'set_pathes'. It will add the Constrained EM directories, as well the BNT to your Matlab path.
4. Run the demo 'test_constrainedEM' from the same directory. It will randomize a data set and equivalence constraints,
    then run some variations of constrainedEM. If everything is fine, It will display several figures and z-score results.




Using Constrained EM :


The main function of the Constrained EM algorithm is mixture_of_gaussians3 which can be found in the EM directory.
This function gets as parameters a data set and a set of positive and negative equivalence constraints. It implements
the Constrained EM algorithm and returns a mixture model which is a local maximum of the data+constraints log-likelihood.
The function can be used as follows :

[results , logLikelihood ,groups ] = mixture_of_gaussians3( data , k , chunks , anti_chunks );

The function parameters in this call are 

 data    -    The data set. Every row is a feature vector of a data instance. data(i,:) contains data instance 'i'. 
 k       -    The number of components in the required Gaussian mixture.       
 chunks  -    Positive constraints vector (constraints of the form 'points a and b belong to the same class').
	      It is an integer tag vector with dimensions 1*length(data). Entrance i of the vector relates to data 
	      instance i. When several data points are known to be from the same class, their indexes in this vector
	      should be identical positive integers to indicate the constraint. A '-1' tag indicates that the data 
	      instance isn't positively constrained. 
	      For example: 		chunks=[2 -1 2 1 -1 -1 2 ] indicates that 
                           Data instances 1,3 and 7 are from the same class.
                           Data instances 4 and 6 are from the same class.
                           Data instances 2 and 5 are not constrained.
              Remember that the sets of instances {1,3,7} and {4,6} might belong to the same class and might belong 
	      to different classes.
anti _ chunks    -   Negative constraints table. (constraints of the form 'points and b belong to different classes'). 
	      It is a table with dimensions (length of data set)*2 containing index pairs indicating negative
	      constraints. Each pair contains the indexes of two data instances which are known to belong to different
	      classes. 
              For example: 		 anti_chunks=[ 1 ,5 ; 
					               6 ,3 ;
                                                       1 ,4 ]  indicates that 
			   Data instances 1 and 5 belong to different classes.
			   Data instances 6 and 3 belong to different classes.
			   Data instances 1 and 4 belong to different classes.

The arguments returned by this call are 	
		
results -     The parameters of the model found. This model gives a local maximum to the constrained data likelihood. 
	      The parameters are given in a cell of kX3 arguments : 
                               results(:,1) are the Gaussian centers (vectors). 
                               results(:,2) are the Gaussian covariance matrixes. 
                               results(:,3) are the mixture weights (scalars ). 

logLikelihood   -   A log of the log-likelihood decrease. It is a vector with dimensions of 1*(number of EM iterations)
	      Entrance i of the vector contains the log-likelihood of the model after i-1 iterations. 

groups -      An assignment vector of dimensions 1*(number of data instances).
	      The i entrance of the vector contains the MAP assignment of data point i (the index of the Gaussian model
	      best explaining it). The MAP assignment is computed using the constraints network and the mixture model
	      found, and it thus complies with the constraints (subject to certain limitation - see the
	      mixture_of_gaussians3 documentation regarding that).

There are many other possible calls to this function. Further documentation is available at the mixture_of_gaussians3
m file. 




Using RCA :

An RCA function can be found in the EM directory under that name (RCA). It takes as argument a data set and a set of 
positive constraints and returns a linear transformation of the data space into better representation (or,
 alternatively, a Mahalanobis metric over the data space). The new representation is known to be optimal in an 
information theoretic sense under a constraint of keeping equivalent data points close to each other.

The function can be used as follows :

[ B, A, newData ]  =  RCA( data, chunks )

The function parameters in this call are 

data    -    The data set. Every row is a feature vector of a data instance. data(i,:) contains data instance 'i'. 
chunks  -    Positive constraints vector (constraints of the form 'points a and b belong to the same class').
	      It is an integer tag vector with dimensions 1*length(data). Entrance i of the vector relates to data 
	      instance i. When several data points are known to be from the same class, their indexes in this vector
	      should be identical positive integers to indicate the constraint. A '-1' tag indicates that the data 
	      instance isn't positively constrained. 
	      For example: 		chunks=[2 -1 2 1 -1 -1 2 ] indicates that 
                           Data instances 1,3 and 7 are from the same class.
                           Data instances 4 and 6 are from the same class.
                           Data instances 2 and 5 are not constrained.
              Remember that the sets of instances {1,3,7} and {4,6} might belong to the same class and might belong 
	      to different classes.

The arguments returned by this call are 
				
B        - 	The RCA suggested Mahalanobis matrix. distances between data points x1,x2 should be computed by
					(x2-x1)'*B*(x2-x1)
A        - 	The RCA suggested transformation of the data. The data should be transformed by A*data. 
newData  - 	The data after the RCA transformation (A). newData=A*data.

The three returned argument are just different forms of the same output. If one is interested in a Mahalanobis metric
over the original data space, the first argument is all he needs. If a transformation into another space (where one
can use the Euclidean metric) is preferred, the second returned argument is sufficient. 
Using A and B is equivalent in the following sense : if y1=A*x1, y2=A*y2  then

					(x2-x1)'*B*(x2-x1) = (y2-y1)'*(y2-y1)




Further help :

The papers relevant to Constrained EM are 'Enhancing image and video retrieval:learning via equivalence constraints',
'Computing Gaussian mixture models with EM using side information'. A summary of RCA appears in 'Learning distance
 functions using equivalence relations'. All the papers can be downloaded from  http://www.cs.huji.ac.il/~daphna/#recent

I can answer simple questions concerning the code at aharonbh@cs.huji.ac.il



