function  engine=reduce_local_net2( engine, pots);
% reduce a connected inference net to a tree by weighting the arcs and calling
% minimal spanning tree algorithm
% the arc weights are determined by the potentials at both ends of the arc .  it
% is p1*p2'.
% engine - a struct with mnet containing the adjacency matrix.
% pots - (number of nodes * variables number of values) table containing the
% potentials at the nodes of the graph

% create a node_arc incidence matrix and costs vector for mst function
global anti_chunks_pruned;
global anti_chunk_num;
adj=engine.mnet;
k=length(adj);		% number of nodes
[x y]=find(triu(adj)==1);
l=length(x);		% number of arcs;

if ~(k-1==l)        % if component isn't a tree already
    pots=pots./(sum(pots')'*ones(1,size(pots,2)));	% normalize pots before determining costs 
    costs=-sum((pots(x,:).*pots(y,:))');
    
    % find minimal spanning tree and adjust the inference engine
    [jnk,ind]=sort(costs);
    mst=mstree([x(ind),y(ind),jnk'],k);
    anti_chunks_pruned=anti_chunks_pruned+l-k+1;
    anti_chunk_num=anti_chunk_num-(l-k+1);
    adj=zeros(k,k);
    adj(sub2ind([k k],mst(:,1),mst(:,2)))=1;
    adj(sub2ind([k k],mst(:,2),mst(:,1)))=1;
end

engine = inf_engine_from_mnet(adj,k ,1);	




