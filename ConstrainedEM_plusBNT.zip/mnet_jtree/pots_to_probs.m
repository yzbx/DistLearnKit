function [pots , ll ] = pots_to_probs(nets,pots)
% data - the full data ( not only the networked )
% nets - the nets to do inference in.
% pots - evidence potentials for hidden nodes
% scmf - single cov mat flag.
% pf- partition function as a vector of low order parameters.
% maximize - do sum/max flag 0 = sum

% the probabilities p( xi | cj ) are returned as fields in nets. 
% ll - the log liklihood calculated.

ll=0;
for i=1:length(nets)
   [ pots(nets{i}.h_vars,:) ll_net ]=infer_local_net(nets{i}.engine, pots(nets{i}.h_vars,:));
   ll=ll+ll_net;
end

   
   
