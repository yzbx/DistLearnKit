function [ comps, singles ]=connected_components(gr)
% singles is a list of indexes of single nodes ( unconnected )
% comps is a cell. each cell contains the indexes of a component

n=length(gr);
not_visited=ones(1,n);
sc=1;	% singles counter
cc=1;	% clusters counter
singles=[];
comps=[];

for i=1:n
   if (not_visited(i)==1)
      if sum(gr(i,:))==0
         singles(sc)=i;
         sc=sc+1;
      else
         queue=i;
         not_visited(i)=0;
         ccc=1;	% current cluster counter
         while (~isempty(queue))
            ind=queue(end);	% remove from queue
            comps{cc}(ccc)=ind;	% write in comps record
            ccc=ccc+1;
       
            nei=find( (gr(ind,:).*not_visited) ==1 );
            not_visited(nei)=0;
            queue=[ queue(1:end-1) nei ];	 
         end
         cc=cc+1;
      end
   end
end

   