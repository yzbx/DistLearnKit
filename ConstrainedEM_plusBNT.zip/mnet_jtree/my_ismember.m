function tf = my_ismember(a,s,flag)
s = sort(s(:));
tf = ismembc(a,s);

