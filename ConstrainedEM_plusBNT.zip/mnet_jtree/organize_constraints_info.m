function [ nets ,singles ,nc_inds ,c_inds ,oth , chunklet_sizes ]= ...
   						organize_constraints_info(chunks, anti_chunks ,k );
% create the mapping from observables to hiddens ( not trivial beacuse of the chunklets)
% and the graph of the net (not trivial because of the anti chunkletts )

% nets - subgraph and inference engine for each connected component
% single_h - the indexes (in hidden numbering ) of single hidden nodes.
% nc_inds - indexes (in data numbering ) of non chunkletized points
% c_inds - cell array containing chunkletized points indexes (in data numbering )
% oth - observable to hidden map - place i contain hidden index of observable i.
% the observable to hidden table : first the chunkletts, then regular points.
% chunklet_sizes - pilug of the chunklet_sizes. to be used in partition function 
%						 calculation when late oracle is used.

global reduce_arcs;
global anti_chunk_num;
global hn_weights;	% hidden nodes weights ( for the partition function calculation ).
% chunklets organization  :

plg=pilug(chunks');
nh=plg(1,2)+size(plg,1)-1;	% number of hiddens
nc_inds=find(chunks==-1);	% indexes of non chunklet points
c_inds=[];
for i=2:size(plg,1)			% indexes of chunklet points
   c_inds{i-1}=find(chunks==plg(i,1));
end
if size(plg,1)>1
   chunklet_sizes=pilug(plg(2:end,2)');
else
   chunklet_sizes=[];
end

oth=chunks;		% observable to hidden map (needed to build the big graph )
oth(nc_inds)=size(plg,1) : nh ;

% keep hidden nodes weights to enable easier partition function calculation
tmp=pilug(oth);
hn_weights=tmp(:,2)';

% anti-chunklets organization :

if isempty(anti_chunks)
   singles=1:nh;
   nets=[];
else
   
   % the big graph :
   
   net=zeros(nh,nh);
   inds1=sub2ind([nh nh],oth(anti_chunks(:,1)),oth(anti_chunks(:,2)));
   net(inds1)=1;
   inds2=sub2ind([nh nh],oth(anti_chunks(:,2)),oth(anti_chunks(:,1)));
   net(inds2)=1;
   
   % because of the index reduction caused by going to hiddens the number of anti 
   % chunklets is decreased, and since it is used in aa-pf it is updated here.
   anti_chunk_num=length(union(inds1,inds2))/2;
   
   % turn graph into a group of connected networks 
   
   [ ccs singles ]=connected_components(net);
   nets=cell(length(ccs),1);
   for i=1:length(ccs)
      nets{i}.h_vars = ccs{i};
      if reduce_arcs==0		% no prunning will be done, so the nets are built now
         nets{i}.engine = inf_engine_from_mnet(net(ccs{i},ccs{i}),k );
      else	% don't build Jtree : it will be done after prunning in calc_p_and_pll
         nets{i}.engine.mnet=net(ccs{i},ccs{i});
      end
   end
     
end

