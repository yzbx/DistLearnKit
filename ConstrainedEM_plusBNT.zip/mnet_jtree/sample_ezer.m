function [ sample, labels]=sample_ezer(centers,trans,weights,n)
% create a sample of mog from mog parameters.
% trans - cell of transformation matrixes
% centers - a k*d matrix of the centers.
% n - the size of sample required.

[k , dim ]=size(centers);
sample=[];
labels=[];
scmf=0;
if isempty(trans{2})	% notice single cov mat flag
   scmf=1;
end 

weights=round(weights*n);
if sum(weights~=n) 	% rounding problem created  wrong size sample
   inds=randperm(k);	% choose several cluster indexes
   dif=n-sum(weights);
   weights(inds(1:abs(dif)))=weights(inds(1:abs(dif)))+sign(dif);	% change the choosen clusters.
end


for i=1:k
   cluster_size=weights(i);
   tmp=randn(cluster_size,dim);    % randomize N(0,I)
   if scmf
      transformation=trans{1};
   else
      transformation=trans{i};
   end
   sample=[ sample ;  tmp*transformation+ones(cluster_size,1)*centers(i,:) ];
   labels=[ labels ; i*ones(cluster_size,1) ];
end

