%last modified on 24/4/03 by tomer and aharon for adding weighted distribution on
%points. if potts is modified correctly then all should be o.k (hopefuly).

% last modified by noam 25.6
% 25.6 THE CHANGES MADE IN THE NUMERIC TRICK FOR CHUNKLETS
% THE LOGLIKELIHOOD IS DIFFERENT THAN BEFORE
% 23.6: PAY ATTENTION - IN CASE THERE ARE LABELED POINTS- THE OUTPUTED PROBABILITIES, AND LL ARE JUNK !!! 
% ONLY ASS IS relevant


function [ probabilities , ll , ass ] =calc_ass_and_maxll(data,param,scmf,c_inds,nc_inds,singles)
% calculate the map assignment and it's log liklihood.

% scmf - single cov mat flag.
% c_inds - a cell array of chunklets. each cell contains data index of a chunklet 
% nc_inds - the indexes of points that aren't in any chunklet.
% singles - indexes of hiddens which aren't connected to others.

% ouput :
% probabilities - an array of nh*k of 1 and 0. a 1 at (i,j) indicates hidden i is set to model j in the mpe .
% ass - the map assignment as a set of lables
% ll - the ll of ass

global nets;
global late_oracle;
global exit_flags;

s=size(param);
k=s(1);
s=size(data);
n=s(1);
d=s(2);
ch_num=length(c_inds);
pots=zeros(ch_num+length(nc_inds),k);
pll=0;
w=[];

% calculate p(O|h) for every point and p( O , h) for non chunkletted points.  

for j=1:k
    if scmf==1
        cov_index=1;
    else
        cov_index=j;
    end
    
    tempData=data-ones(n,1)*param{j,1}; % subtract the mean
    covDet=abs(det(param{cov_index,2}));
    if( ( covDet<=(0.01^d) ) & (~scmf) )
        if bitand(exit_flags,16)==0		% covmat is close to singular
            %disp(sprintf( 'covmat %d is close to singular at calc_p_and_pll\n',cov_index));
            exit_flags=bitor(exit_flags,16);		% set bit 4.
        end
    end
    
    expContent=-0.5*sum(tempData*inv(param{cov_index,2}).*tempData,2);    % the exponent content
    
    LogProbs(:,j)= -(d/2)*log(2*pi) -0.5*log(det(param{cov_index,2}))+expContent;
    LogProbs(nc_inds,j)=LogProbs(nc_inds,j)+log(param{j,3});
    
end

% copy the unchunkleted points probabilities to hn probabilities.
LogPots(ch_num+1:ch_num+length(nc_inds),:)=LogProbs(nc_inds,:);

% calculate p (o,h ) for chunkletted data

if ch_num~=0    
    for j=1:ch_num;
        inds=c_inds{j};
        
        log_tmp=LogProbs(inds,:);
        log_alpha=log(cell2mat(param(:,3))');
        if late_oracle
            exp_content=sum(log_tmp)+size(log_tmp,1)*log_alpha;
        else
            exp_content=sum(log_tmp)+log_alpha;
        end
        LogPots(j,:)=exp_content;
    end
end

m=max(LogPots');
LogPots=LogPots- m'*ones(1,k);
addition_to_ll=sum(m);   % ll=log ( sum(k) of exp(m)*exp( alpha_k + sum(i) log (p(x_i|h=k)) )
pots=exp(LogPots);

% the assignment for single hiddens

[ tmp ass(singles) ]=max(pots(singles,:)');
inds=(singles-1)*k+ass(singles);
tmpots=pots';
ll=sum(log( tmpots(inds) ) );      
clear tmpots;


% the assignment for connected hiddens

for i=1:length(nets)
    [ tmp ll_net ass(nets{i}.h_vars) ]=infer_local_net( nets{i}.engine, pots(nets{i}.h_vars,:) ,1 );
    ll=ll+ll_net;
end

nh=length(ass);
probabilities=zeros(k,nh);
probabilities( (0:k:(nh-1)*k )+ass)=1;
probabilities=probabilities';


