function [ass, maxll] = max_distribute_evidence(engine, clpot, seppot)
% my version of finding the maximum assignment, once collect evidence has beed done.
% it is adjusted to the constraint em clustering ( assumes all nodes have same size )

% saving k - the number of clusters
stpot=struct(clpot{engine.preorder(1)} );
k=stpot.sizes(1);

ass=zeros(length(engine.mnet),1);
root_flag=1;

for n=engine.preorder
   % find max assignment
   stpot=struct( clpot{n} );
   tmp=reshape(stpot.T,1,k^length(stpot.sizes));
   [ maxl arg ]=max(tmp);
   local_ass=dec2base(arg-1,k,length(stpot.sizes));
   local_ass=local_ass(end:-1:1);
   ass(stpot.domain)=local_ass-47;
   
   if root_flag	% save the likelihood of the assignment
      maxll=log(maxl);	
      root_flag=0;
   end
   for c=engine.preorder_children{n}
      % reducing the table of nighbour c by cutting through the choosen values
      stpot=struct(clpot{c});
      c_vars=stpot.domain;
      set_inds=ass(c_vars);
      new_vars=c_vars(find(set_inds==0));
      T=stpot.T;
      % preparing a string for the reduction
      str='T=reshape(T(';
      for j=1:length(set_inds)
         if (set_inds(j))
            str=[ str num2str(set_inds(j)) ','];
         else
            str(end+1:end+2)=':,';
         end
      end
      str(end)=')';
      for i=1:length(new_vars)
         str=[str ',' num2str(k) ];
      end
      if length(new_vars)==1
         str=[ str ',1' ];
      end
      str=[ str ');' ];
      
      eval(str,tmp); 		% T=reshape(T(:,:,3,:,5),k,k,k)
      clpot{c}=dpot(new_vars,k*ones(1,length(new_vars)),T);
   end
end

