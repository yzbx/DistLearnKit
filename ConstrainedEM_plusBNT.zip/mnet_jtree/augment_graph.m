function mnet=augment_graph(mnet)
% add the observables to the graph ( net field )
n=size(mnet.net,1);
k=n+1;
for i=1:n
   mnet.net(i,k:k+length(obs{i})-1)=1;
   mnet.net(k:k+length(obs{i})-1,i)=1;
end

   
