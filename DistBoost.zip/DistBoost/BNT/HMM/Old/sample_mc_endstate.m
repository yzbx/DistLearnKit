function S = sample_mc_endstate(startprob, trans, endprob)
% SAMPLE_MC_ENDSTATE Generate a random sequence from a Markov chain until enter the endstate.
% seq = sample_mc(startprob, trans, endprob)

S = [];
S(1) = sample_discrete(startprob);
t = 1;
p = endprob(S(t));
stop = (sample_discrete([p 1-p]) == 1);
while ~stop
  S(t+1) = sample_discrete(trans(S(t),:));
  p = endprob(S(t+1));
  stop = (sample_discrete([p 1-p]) == 1);
  t = t + 1;
end
