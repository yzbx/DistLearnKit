function CPD = learn_params(CPD, fam, data, ns, cnodes)
% LEARN_PARAMS Compute the ML/MAP estimate of the params of a tabular CPD given complete data
% CPD = learn_params(CPD, fam, data, ns, cnodes)
%
% data(i,m) is the value of node i in case m (can be cell array).

if iscell(data)
  local_data = cell2num(data(fam,:));
else
  local_data = data(fam, :);
end
counts = compute_counts(local_data, CPD.sizes);
switch CPD.prior_type
 case 'none', CPD.CPT = mk_stochastic(counts); 
 case 'dirichlet', CPD.CPT = mk_stochastic(counts + CPD.dirichlet); 
 otherwise, error(['unrecognized prior ' CPD.prior_type])
end
