function CPT = CPD_to_CPT(CPD)
% CPD_TO_CPT Convert the discrete CPD to tabular form (tabular)
% CPT = CPD_to_CPT(CPD)

CPT = CPD.CPT;
