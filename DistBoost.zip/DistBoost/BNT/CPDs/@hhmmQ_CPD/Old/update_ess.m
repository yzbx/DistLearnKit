function CPD = update_ess(CPD, fmarginal, evidence, ns, cnodes, hidden_bitv)
% UPDATE_ESS Update the Expected Sufficient Statistics of a hhmm node.
% function CPD = update_ess(CPD, fmarginal, evidence, ns, cnodes, hidden_bitv)

% Figure out the node numbers associated with each parent
% e.g., D=4, d=3, all Qs above parents, so dom = [Q3(t-1) F4(t-1) F3(t-1) Q1(t) Q2(t) Q3(t)].
% so self = Q3(t), old_self = Q3(t-1), CPD.Qps = [1 2], Qps = [Q1(t) Q2(t)]
dom = fmarginal.domain;
self = dom(end);
old_self = dom(1);
nps = length(CPD.Qps);
if nps == 0
  Qps = [];
else
  Qps = dom(length(dom)-nps:end-1);
end

Qsz = CPD.Qsizes(CPD.d);
Qpsz = prod(CPD.Qsizes(CPD.Qps));

% If some of the Q nodes are observed (which happens during supervised training)
%, the counts will only be non-zero in positions
% consistent with the evidence. We put the computed marginal responsibilities
% into the appropriate slots of the big counts array.
% (Recall that observed discrete nodes only have a single effective value.)
% (A much slower way is to call add_evidence_to_dmarginal.)
% We assume the F nodes are never observed.
ps = dom(1:end-1);
if ~hidden_bitv(self) % I'm observed  - so we assume all Q parents are also observed
  self_val = evidence{self};
  oldself_val = evidence{old_self};
  if ~isempty(Qps)
    Qps_val = subv2ind(Qpsz, cat(1, evidence(Qps)));
  end
end


if CPD.d==1
  if ~CPD.F1toQ1
    % marg(Q1(t-1), F2(t-1), Q1(t))                            
    % F2(t-1) P(Q1(t)=j | Q1(t-1)=i)
    % 1       delta(i,j)
    % 2       transprob(i,j)
    if ~hidden_bitv(self)
      hor_counts = zeros(Qsz, Qsz);
      hor_counts(oldself_val, self_val) = fmarginal.T(2);
    else
      marg = reshape(fmarginal.T, [Qsz 2 Qsz]);
      hor_counts = squeeze(marg(:,2,:));
    end
  else
    % marg(Q1(t-1), F2(t-1), F1(t-1), Q1(t))                            
    % F2(t-1) F1(t-1)  P(Qd(t)=j| Qd(t-1)=i)
    % ------------------------------------------------------
    % 1        1         delta(i,j)
    % 2        1         transprob(i,j)
    % 1        2         impossible
    % 2        2         startprob(j)
    if ~hidden_bitv(self)
      marg = myreshape(fmarginal.T, [1 2 2 1]);
      hor_counts = zeros(Qsz, Qsz);
      hor_counts(oldself_val, self_val) = fmarginal.T(1,2,1,1);
      ver_counts = zeros(Qsz, 1);
      ver_counts(self_val) = fmarginal.T(1,2,2,1);
    else
      marg = reshape(fmarginal.T, [Qsz 2 2 Qsz]);
      hor_counts = squeeze(marg(:,2,1,:));
      ver_counts = squeeze(sum(marg(:,2,2,:),1)); % sum over i
    end
  end % F1toQ1
else
  if CPD.d == CPD.D
    % marg(QD(t-1), FD(t-1), Qps(t), QD(t))                            
    % FD(t-1) P(QD(t)=j | QD(t-1)=i, Qps(t)=k)
    % 1      transprob(i,k,j) 
    % 2      startprob(k,j)
    if ~hidden_bitv(self)
      marg = myreshape(fmarginal.T, [1 2 1 1]);
      hor_counts = zeros(Qsz, Qpsz, Qsz);
      hor_counts(oldself_val, Qps_val, self_val) = fmarginal.T(1, 1, 1,1);
      ver_counts = zeros(Qpsz, Qsz);
      ver_counts(Qps_val, self_val) = fmarginal.T(1, 2, 1,1);
    else
      marg = reshape(fmarginal.T, [Qsz 2 Qpsz Qsz]);
      hor_counts = squeeze(marg(:,1,:,:));
      ver_counts = squeeze(sum(marg(:,2,:,:),1)); % sum over i
    end
  else
    % marg(Qd(t-1), Fd+1(t-1), Fd(t-1), Qps(t), Qd(t))                            
    % Fd+1(t-1) Fd(t-1)  P(Qd(t)=j| Qd(t-1)=i, Qps(t)=k)
    % ------------------------------------------------------
    % 1        1         delta(i,j)
    % 2        1         transprob(i,k,j)
    % 1        2         impossible
    % 2        2         startprob(k,j)
    if ~hidden_bitv(self)
      marg = myreshape(fmarginal.T, [1 2 2 1 1]);
      hor_counts = zeros(Qsz, Qpsz, Qsz);
      hor_counts(oldself_val, Qps_val, self_val) = fmarginal.T(1, 2,1, 1,1);
      ver_counts = zeros(Qpsz, Qsz);
      ver_counts(Qps_val, self_val) = fmarginal.T(1, 2,2, 1,1);
    else
      marg = reshape(fmarginal.T, [Qsz 2 2 Qpsz Qsz]);
      hor_counts = squeeze(marg(:,2,1,:,:)); % i,k,j
      ver_counts = squeeze(sum(marg(:,2,2,:,:),1)); % sum over i
    end
  end
end

CPD.sub_CPD_trans = update_ess_simple(CPD.sub_CPD_trans, hor_counts);

if ~isempty(CPD.sub_CPD_start)
  CPD.sub_CPD_start = update_ess_simple(CPD.sub_CPD_start, ver_counts);
end


% Q1 obsevred
if CPD.obsQ
  dom = fmarginal.domain;
  nstates = length(CPD.transprob);
  counts = zeros(nstates, nstates);
  oldQ = evidence{dom(1)};
  Q = evidence{dom(3)};
  counts(oldQ, Q) = marg(2);
else
  counts = squeeze(marg(:,2,:));
end

