function CPD = update_CPT(CPD)
% Compute the big CPT for an HHMM Q node (including F parents) given internal transprob and startprob
% function CPD = update_CPT(CPD)

if (CPD.d==1)
  if ~CPD.F1toQ1 % no F from self, hence no startprob
    Qsz = size(CPD.transprob,1);
    % F2(t-1) P(Q1(t)=j | Q1(t-1)=i)
    % 1       delta(i,j)
    % 2       transprob(i,j)
    CPT = zeros(Qsz, 2, Qsz);
    CPT(:, 1, :) = eye(Qsz);
    CPT(:, 2, :) = CPD.transprob;
  else
    % F2(t-1) F1(t-1)  P(Qd(t)=j| Qd(t-1)=i)
    % ------------------------------------------------------
    % 1        1         delta(i,j)
    % 2        1         transprob(i,j)
    % 1        2         impossible
    % 2        2         startprob(j)
    CPT = zeros(Qsz, 2, 2, Qsz);
    CPT(:, 1, 1, :) = eye(Qsz);
    CPT(:, 2, 1, :) = CPD.transprob;
    CPT(:, 1, 2, :) = eye(Qsz);
    CPT(:, 2, 2, :) = repmat(reshape(CPD.startprob, [1 Qsz]), [Qsz 1]); % replicate over i
  end
else
  [Qsz Qpsz Qsz2] = size(CPD.transprob);
  if CPD.d==CPD.D % no F from below
    % FD(t-1) P(QD(t)=j | QD(t-1)=i, Qps(t)=k)
    % 1      transprob(i,k,j) 
    % 2      startprob(k,j)
    CPT = zeros(Qsz, 2, Qpsz, Qsz);
    CPT(:, 1, :, :) = CPD.transprob;
    CPT(:, 2, :, :) = repmat(reshape(CPD.startprob, [1 Qpsz Qsz]), [Qsz 1 1]); % replicate over i
  else % general case
    % Fd+1(t-1) Fd(t-1)  P(Qd(t)=j| Qd(t-1)=i, Qps(t)=k)
    % ------------------------------------------------------
    % 1        1         delta(i,j)
    % 2        1         transprob(i,k,j)
    % 1        2         impossible
    % 2        2         startprob(k,j)
    CPT = zeros(Qsz, 2, 2, Qpsz, Qsz);
    I = repmat(eye(Qsz), [1 1 Qpsz]); % i,j,k
    I = permute(I, [1 3 2]); % i,k,j
    CPT(:, 1, 1, :, :) = I;
    CPT(:, 2, 1, :, :) = CPD.transprob;
    CPT(:, 1, 2, :, :) = I;
    CPT(:, 2, 2, :, :) = repmat(reshape(CPD.startprob, [1 Qpsz Qsz]), [Qsz 1 1]); % replicate over i
  end
end

CPD = set_fields(CPD, 'CPT', CPT);          
