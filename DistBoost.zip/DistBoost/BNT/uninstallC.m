dirs = {'potentials/Tables', 'misc', 'CPDs/@discrete_CPD', ...
      'inference/static/@jtree_ndx_inf_engine', 'inference/static/@jtree_sparse_inf_engine', ...
      'inference/static/@jtree_C_inf_engine', 'inference/static/@gibbs_sampling_inf_engine/private', ...
   	'inference/static/@gibbs_sampling_inf_engine', ...
	   'graph/C', 'Entropic/Brand'};

global BNT_HOME

for d=1:length(dirs)
  f = fullfile(BNT_HOME, dirs{d});
  fprintf('removing C/mex files from %s\n', f);
  cd(f)
  delete *.mex*
  delete *.dll
  delete *.obj
  delete *.o
end
