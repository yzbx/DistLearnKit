function count = compute_counts(data, sz)
% COMPUTE_COUNTS Compute the number of times each combination of assignments occurs
% count = compute_counts(data, sz)
%
% data(i,l) is the value of node i in case l (not a cell array!).
% sz is a list of the sizes of each node (number of values it can take on).

assert(length(sz) == size(data, 1));
P = prod(sz);
indices = subv2ind(sz, data'); % each row of data' is a case 
%count = histc(indices, 1:P);
count = hist(indices, 1:P);
count = myreshape(count, sz);

