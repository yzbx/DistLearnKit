function [bnet, LL, BIC_score] = learn_params_tabular(bnet, data)
% LEARN_PARAMS_TABULAR Find the maximum likelihood params for a fully observed tabular model
% [bnet, LL, BIC_score] = learn_params_tabular_ML(bnet, data)
%
% This is just a special case of learn_params, and should not be used!
% It is being kept merely for backwards compatibility with BNT2

tiny = exp(-700);
n = length(bnet.dag);
ll = zeros(1, n);
nparams = zeros(1,n);
ncases = size(data, 2);
ns = bnet.node_sizes;
for i=1:n
  if adjustable_CPD(bnet.CPD{i})
    ps = parents(bnet.dag, i);
    dom = [ps i];
    counts = compute_counts(data(dom,:), ns(dom));
    CPT = mk_stochastic(counts);
    bnet.CPD{i} = tabular_CPD(bnet, i, CPT);
    ll(i) = sum(log(CPT(:)  + tiny) .* counts(:));
    % CPT(i) = 0 iff counts(i) = 0 so it is okay to add tiny
    nparams(i) = prod([ns(ps) ns(i)-1]);
    %fprintf('node %d, L %6.4f, params %d\n', i, ll(i), nparams(i));
    % sum-to-1 constraint reduces the effective num. vals of the node by 1
  end
end

LL = sum(ll);
D = sum(nparams);
BIC_score = LL - 0.5*D*log(ncases);
