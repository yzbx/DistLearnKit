function [bnet, LL, BIC_score] = learn_params(bnet, data)
% LEARN_PARAMS Find the maximum likelihood params for a fully observed model
% [bnet, LL, BIC_score] = learn_params(bnet, data, ...)
%
% data(i,m) is the value of node i in case m (can be a cell array)
% We set bnet.CPD{i} to its MLE.
% LL = log likelihood 
% BIC_score is an approx. to the log marginal likelihood.
%
% The following optional arguments can be specified in the form of name/value pairs:
% [default value in brackets]
%
% clamped    - clamped(i,m) = 1 if node i is clamped in case m [ zeros(N, ncases) ]
%
% Currently we assume no param tying

[n ncases] = size(data);
BIC = zeros(1,n);
L = zeros(1,n);
for j=1:n
  e = bnet.equiv_class(j);
  assert(e==j);
  if adjustable_CPD(bnet.CPD{e})
    ps = parents(bnet.dag, j);
    bnet.CPD{j} = learn_params(bnet.CPD{j}, [ps j], data, bnet.node_sizes, bnet.cnodes);
    L(j) = log_prob_node(bnet.CPD{j}, data(j,:), data(ps,:));
    S = struct(bnet.CPD{j}); % violate object privacy
    % fprintf('node %d, L %6.4f, params %d\n', j, L(j), S.nparams);
    BIC(j) = L(j) - 0.5*S.nparams*log(ncases);
  end
end
LL = sum(L);
BIC_score = sum(BIC);
