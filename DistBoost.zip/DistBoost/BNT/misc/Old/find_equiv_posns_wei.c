#include "mex.h"

/*
MEX version of find_equiv_posns.
Modified from find_equiv_posns_broken.c.
By Wei Hu, 10/08/2001.
*/


void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  int i, j, ns, nl, count;
  int *find;
  double *vsmall, *vlarge, *p;

  ns = nl = 0;

  vsmall = mxGetPr(prhs[0]);
  ns = mxGetNumberOfElements(prhs[0]);
  if(ns == 0){
	  plhs[0] = mxCreateDoubleMatrix(1, 0, mxREAL);
	  return;
  }

  vlarge = mxGetPr(prhs[1]);
  nl = mxGetNumberOfElements(prhs[1]);

  find = malloc(ns * sizeof(int));
  count = 0;

  for (i = 0; i < ns; i++) {
    for (j = 0; j < nl; j++) {
      if (vlarge[j] == vsmall[i]) {
    	find[count]=j+1;
		count++;
    	break;
      }
    }
  }
  plhs[0] = mxCreateDoubleMatrix(1, count, mxREAL);
  p = mxGetPr(plhs[0]);
  for(i=0; i<count; i++){
	  p[i] = find[i];
  }
  free(find);
}
