#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "mex.h"

/*
MEX version of find_equiv_posns.
*/

#define MAX(i,j) ((i)>(j)?(i):(j))


void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  int i, j, ns, nl, found;
  double *vsmall, *vlarge, *p;

  ns = nl = 0;

  vsmall = mxGetPr(prhs[0]);
  ns = length(prhs[0]);

  vlarge = mxGetPr(prhs[1]);
  nl = length(prhs[1]);

  plhs[0] = mxCreateDoubleMatrix(1, ns, mxREAL);
  p = mxGetPr(plhs[0]);

  for (i = 0; i < ns; i++) {
    found = 0;
    for (j = 0; j < nl; j++) {
      if (vlarge[j]==vsmall[i]) {
	p[i]=j+1;
	found = 1;
	break;
      }
    }
    if (!found) mexErrMsgTxt("small domain must occur in large one\n"); 
  }

}



int length(const mxArray *p)
{
  int r, c, n;
  r = mxGetM(p);
  c = mxGetN(p);
  n = MAX(r,c);
  if ((r==0) || (c==0)) n = 0; /* empty matrix */
  return n;
}
