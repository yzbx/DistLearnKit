function x = greedy_set_cover(A, c)
% GREEDY_SET_COVER Greeedy heuristic for set covering problem
% x = greedy_set_cover(A, c)
%
% The goal is to find a set x such that every row of A has not empty intersection with x.
% Define A(i,j) = 1 if case i contains element j and is 0 otherwise.
% Then x = min  sum_j c(j) x(j) s.t. sum_j A(i,j) x(j) >= 1, x is an n bit vector.
% A is an m x n 0/1 matrix and c is an optional n-vector of costs (default: all 1s).
%
% We use the greedy heuristic on p466 of "Integer and Combinatorial Optimization",
% Nemhauser and Wolsey, Wiley 1988.
% This selects the column that covers the largest number of uncovered rows per unit cost,
% and stops as soon as a feasible solution is found.
%
% Example: sets = {1,2}  {2,3} {1,3}
% A = [1 1 0;
%      0 1 1;
%      1 0 1];
% x = [1 1 0], i.e,, {1,2}  (the output needn't be one of the input sets)


[m n] = size(A);
if nargin < 2, c = ones(1, n); end
ms = 1:m;
ns = 1:n;
done = 0;
t = 1;
Tmax = 100;
while ~done & t < Tmax
  score = zeros(1, length(ns));
  for ji=1:length(ns)
    j = ns(ji);
    Mj = find(A(:,j)==1);
    L = length(myintersect(Mj, ms));
    if L == 0
      score(ji) = inf;
    else
      score(ji) = c(j) / L;
    end
  end
  j = ns(argmin(score));
  Mj = find(A(:,j)==1); 
  assert(~isempty(Mj));
  ns = mysetdiff(ns, j);
  ms = mysetdiff(ms, Mj);
  if isempty(ms)
    x = zeros(1, n);
    ns_bitv = zeros(1, n);
    ns_bitv(ns) = 1;
    x(logical(~ns_bitv)) = 1; % the eliminated ns are the ones to keep
    done = 1;
  else
    t = t + 1;
  end
end

if t >= Tmax
  error('exceeded max iter');
end
