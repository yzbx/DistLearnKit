function [T, perm] = sortcell(T)
% SORTCELL Sort elements of a 1D cell array first by length, then in ASCII order
% [T, perm] = sortcell(T)
%
% Example
% [T, perm] = sortcell({[2 3], [1 2], 1})
% T = { [1], [1 2], [2 3] }
% perm = [3 2 1]

% first sort by length
m = length(T);
L = zeros(1,m);
for s=1:m
  L(s) = length(T{s});
end
[L, perm] = sort(L);
T = T(perm);

% now sort each block of same length
U = unique(L);
h = hist(L, 1:max(L)); % how many entries of each length
H = cumsum(h);
for i=1:length(H)
  if i==1
    ndx = 1:H(1);
  else
    ndx = H(i-1)+1:H(i);
  end
  M = T(ndx);
  M = cat(1, M{:});
  [M, perm2] = sortrows(M);
  T(ndx) = num2cell(M,2);
  p = perm(ndx);
  perm(ndx) = p(perm2);
end
  
