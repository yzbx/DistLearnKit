function C = num2strcell(A)
% NUM2STRCELL Convert an array to a cell array of strings
% C = num2strcell(A)
% e.g., num2strcell(1:3) = { '1', '2', '3' }

method = 3;
switch method
 case 1,
  n = length(A);
  %C1 = num2cell(A);
  C = cell(1,n);
  for i=1:n
    %C{i} = num2str(C1{i});
    C{i} = num2str(A(i));
  end
 case 2,
  % Peter J. Acklam <jacklam@math.uio.no>
  C = fmap('num2str', num2cell(A));
 case 3,
  % Dominique Marcenac <dominique.marcenac@bt.com>
  n = length(A);
  C1=sprintf('%2d',A);
  C2=reshape(C1,2,n)';
  C=num2cell(C2,2);
end
