% VERSION_BNT What is the version of your BNT ?
% version_BNT
% philippe.leray@insa-rouen.fr

if ~exist('BNT_HOME')
  fprintf('Launch add_BNT_to_path from your BNT directory\n');
  fprintf('cf. installation procedure\n\n');
else
  eval(sprintf('type %s/README.txt', BNT_HOME));
end
