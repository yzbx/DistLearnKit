function Y = find_first_change(X)
%
% Example
%>> input = X =
%>>    0 0 0
%>>    1 0 0
%>>    0 0 1
%>>    1 0 1
%>> output = Y = [2 -1 3]

%Yasushi KONDOH <ykondo@eco.toyama-u.ac.jp>
n = size( X, 1 );  Y = n - sum( cumsum(X) > 0  ) + 1;  Y( Y > n ) = -1; 
