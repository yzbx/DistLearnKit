
#include "mex.h"
#include <stdio.h>

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  int i, N;  

  const mxArray *cache_ptr;
  double *cache, *ndx;
  
  cache_ptr = mexGetArrayPtr("CACHE", "caller");
  
  printf("\n");
}
