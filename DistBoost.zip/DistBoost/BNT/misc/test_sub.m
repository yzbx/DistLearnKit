
n = 4;
sz=2*ones(1,n);
subs=ind2subv(sz, 1:2^n);
T = 2;

tic
for t=1:T
  ndxm = subv2ind(sz, subs);
end
toc

if 0
tic
for t=1:T
  ndxc = subv2ind_c(sz, subs);
end
toc
isequal(ndxm, ndxc)
isequal(ndxm, ndxc+1)
end
