function d = distance(u, v)

delta = u - v;
d = sqrt(sum(delta .^ 2));
