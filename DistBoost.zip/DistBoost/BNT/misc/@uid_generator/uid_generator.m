function gen = uid_generator()
% UID_GENERATOR Object that returns an integer to uniquely encode an object
% gen = uid_generator
% 
% This is a bit like a hash table, but less efficient

gen.last_id = 0;
gen.objects = {};
gen = class(gen, 'uid_generator');

