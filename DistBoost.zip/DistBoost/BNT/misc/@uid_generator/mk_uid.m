function [id, new_id, gen] = mk_uid(gen, obj)
% MK_UID Make a unique id
% [id, new_id, gen] = mk_uid(gen, obj)
%
% If obj has appeared before, we return its id, otherwise generate a new number.
% It must appear in exactly the same form.
% We do a sequential search...

new_id = 0;
for i=1:length(gen.objects)
  if isequal(obj, gen.objects{i})
    id = i;
    return;
  end
end
gen.last_id = gen.last_id + 1;
id = gen.last_id;
gen.objects{id} = obj;
new_id = 1;

%fprintf('assigning id %d to \n', id);
%celldisp(obj)


    
