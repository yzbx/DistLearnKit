function hmm = mk_dhmm_ex1()

% generate strings of the form 1 3^* 1 | 2 3^* 2
% using the HMM in Stolcke's thesis p52

hmm.nstates = 6;
hmm.nobs = 3;
hmm.type = 'discrete';

hmm.startprob = [0 0.5 0 0.5 0 0];
hmm.endprob = [0 0 1 0 0 1];

hmm.transmat = [0.5 0.0 0.5 0.0 0.0 0.0
		0.5 0.0 0.5 0.0 0.0 0.0
		0.0 0.0 0.0 0.0 0.0 0.0
		0.0 0.0 0.0 0.0 0.5 0.5
		0.0 0.0 0.0 0.0 0.5 0.5
		0.0 0.0 0.0 0.0 0.0 0.0];

hmm.obsmat = [0 0 1
	      0 1 0
	      0 1 0
	      1 0 0
	      0 0 1
	      1 0 0];


