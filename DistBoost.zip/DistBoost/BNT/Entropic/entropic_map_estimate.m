function [theta, loglik] = entropic_map_estimate(counts, Z)
% ENTROPIC_MAP_ESTIMATE Find MAP estimate of multinomial using entropic prior
% [theta, loglik] = entropic_map_estimate(counts, Z)
%
% The entropic prior says P(theta) \propto exp(-H(theta)), where H(.) is the entropy.
%
% Z = 1 (default) is min entropy
% Z = 0 is max likelihood,
% Z = -1 is max ent,
% Z = -inf corresponds to very high temperature (good for initialisation)
%
% Based on "Structure learning in conditional probability models via an entropic prior
% and parameter extinction", M. Brand, Neural Computation 11 (1999): 1155--1182
%
% For the Z ~= 1 case, see "Pattern discovery via entropy minimization",
% M. Brand, AI & Statistics 1999. Equation numbers refer to this paper.
%
% This function is just a stub for calling Matt Brand's C code.
% We use the stub so that tabular_CPD/maximize_params doesn't complain about 'entropic_map'
% not existing in the event that we don't install the C code.

[theta, loglik] = entropic_map(counts, Z);
