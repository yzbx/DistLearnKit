/*
   function x = lambertwn1(y)
*/
  
#define FUNCTION lambertwn1
#include "lambert.c"
