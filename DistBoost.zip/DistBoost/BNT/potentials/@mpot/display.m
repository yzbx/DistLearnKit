function display(pot)

disp('moment Gaussian potential object');
disp(struct(pot));
