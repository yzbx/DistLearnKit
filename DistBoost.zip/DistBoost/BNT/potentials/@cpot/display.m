function display(pot)

disp('canonical potential object');
disp(struct(pot));
