function pot = set_domain_pot(pot, domain)
% SET_DOMAIN_POT Change the domain of a potential (dpot)
% pot = set_domain_pot(pot, domain)

pot.domain = domain;
