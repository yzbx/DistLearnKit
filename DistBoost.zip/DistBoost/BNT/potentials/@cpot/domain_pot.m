function dom = domain_pot(pot)
% DOMAIN_POT Return the domain of this cpot.
% dom = domain_pot(pot)

dom = pot.domain;
