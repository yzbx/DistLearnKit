function id = add_ndxD(bigdom, smalldom, ns)
% ADD_NDXD Possibly add new indexes to the global cache
% id = add_ndxD(bigdom, smalldom, ns)
%
% ns is the node sizes of all nodes
% id is the identifier for the cache entry, new or existing.

global D_NDX
ndx = mk_ndxD(bigdom, smalldom, ns);

ndxD_len = length(D_NDX);
for i=1:ndxD_len
  if isequal(ndx, D_NDX{i})
    id = i;
    return;
  end
end

id = ndxD_len + 1;
D_NDX{id} = ndx;
