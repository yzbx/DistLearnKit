/* C mex version for mult_by_table_ndxD.m in potential/Tables directory  */

#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
	double  *pb, *ps;
	int     i, j, I, J, N, pointer, temp;
	int     *ndx;
	char    *used;

	plhs[0] = mxDuplicateArray(prhs[0]);
	N = mxGetNumberOfElements(plhs[0]);
	pb = mxGetPr(plhs[0]);
	ps = mxGetPr(prhs[1]);
	ndx = mxGetData(prhs[2]);
	J = mxGetNumberOfElements(prhs[2]);
	I = N / J;

	if(J == 1){
		for(i=0; i<N; i++){
			*pb++ *= *ps++;
		}
		return;
	}

	if(I == 1){
		for(i=0; i<N; i++){
			*pb++ *= *ps;
		}
		return;
	}

	used = (char *)malloc(N * sizeof(char));
	for(i=0; i<N; i++){
		used[i] = 0;
	}
	pointer = 0;
	for(i=0; i<I; i++){
		while(used[pointer]){
			pointer++;
		}
		temp = pointer;
		used[pointer] = 1;
		for(j=0; j<J; j++){
			temp = pointer + ndx[j];
			pb[temp] *= *ps;
			used[temp] = 1;
		}
		ps++;
		pointer++;
	}
	free(used);
}
