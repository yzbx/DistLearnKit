function diff_ndx = mk_ndxD(bigdom, smalldom, ns)
% MK_NDX Make the indices needed to speedup table manipulation
% [small_ndx, diff_ndx] = mk_ndx(bigdom, smalldom, ns)
%
% For an explanation, see test_mult_ndx1D.m

% small_ndx is an Sx1 vector, and diff_ndx is a Dx1 vector

ns = ns(:)';
map = find_equiv_posns(smalldom, bigdom);

sz = ns(bigdom);
sz(map) = 1;
diffdom = mysetdiff(bigdom, smalldom);
D = prod(ns(diffdom));
subs = ind2subv(sz, 1:D);
diff_ndx = subv2ind(ns(bigdom), subs)' - 1; % we subtract 1 so both ndx arrays start from 0
diff_ndx = int32(diff_ndx);
