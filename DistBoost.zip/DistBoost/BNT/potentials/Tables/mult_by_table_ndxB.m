function Tbig = mult_by_table_ndxB(Tbig, Tsmall, ndx)
% MULT_BY_TABLE_NDXB Tbig *= Tsmall
% Tbig = mult_by_table_ndxB(Tbig, Tsmall, ndx)

ndx = double(ndx) + 1;
Tsmall = Tsmall(ndx);
Tbig(:) = Tbig(:) .* Tsmall(:);
