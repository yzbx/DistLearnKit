function id = add_ndxSD(bigdom, smalldom, ns)
% ADD_NDX Possibly add new indexes to the global cache
% id = add_ndx(bigdom, smalldom, ns)
%
% ns is the node sizes of all nodes
% id is the identifier for the cache entry, new or existing.

global SD_NDX   SD_UID_GEN   
[id, newid, SD_UID_GEN] = mk_uid(SD_UID_GEN, {ns(bigdom), find_equiv_posns(smalldom, bigdom)});
if newid
  [ndx.small, ndx.diff] = mk_ndxSD(bigdom, smalldom, ns);
  SD_NDX{id} = ndx;
end
