function ndx = mk_ndxB(bigdom, smalldom, ns)
% MK_NDXB Compute mapping from small table to big table
% ndx = mk_ndxB(bigdom, smalldom, ns)
%
% Example: bigdom = [a b c d], smalldom = [b c], then ndx([a b c d]) = [b c]
% so we can implement multiply_by_table as
% for i=1:prod(ns(bigdom))
%   big(i) = big(i) * small(ndx(i))
% end
% or big = big .* small(ndx)


mask = find_equiv_posns(smalldom, bigdom);
N = prod(ns(bigdom));
subs = ind2subv(ns(bigdom), 1:N);
ndx = subv2ind(ns(smalldom), subs(:,mask));

if isempty(smalldom)
   ndx = 0;
else
   S = prod(ns(smalldom));
   D = N / S;
   ndx = reshape(ndx-1, S, D);
end
ndx = int32(ndx);
