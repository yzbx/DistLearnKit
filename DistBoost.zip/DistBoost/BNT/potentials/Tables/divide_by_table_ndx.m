function Tbig = divide_by_table_ndx(Tbig, Tsmall, ndx, ndx_type)
% DIVIDE_BY_TABLE_NDX Tbig /= Tsmall
% function Tbig = divide_by_table_ndx(Tbig, Tsmall, ndx, ndx_type)

switch ndx_type
 case 'SD', Tbig = divide_by_table_ndxSD(Tbig, Tsmall, ndx);
 case 'D', Tbig = divide_by_table_ndxD(Tbig, Tsmall, ndx);
 case 'B', Tbig = divide_by_table_ndxB(Tbig, Tsmall, ndx);
 otherwise, error(['unrecognized ndx type ' ndx_type])
end
  
