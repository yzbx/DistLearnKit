/* C mex version for mult_by_table_ndx.m in potential/Tables directory  */

#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
  mxArray *ptemp;
  double  *Tbig, *Tsmall;
  int     *small_ndx, *diff_ndx;
  int     i, j, k, S, D;

  plhs[0] = mxDuplicateArray(prhs[0]);
  Tbig = mxGetPr(plhs[0]);
  Tsmall = mxGetPr(prhs[1]); 

  ptemp = mxGetField(prhs[2], 0, "small");
  small_ndx = mxGetData(ptemp);
  S = mxGetNumberOfElements(ptemp);

  ptemp = mxGetField(prhs[2], 0, "diff");
  diff_ndx = mxGetData(ptemp);
  D = mxGetNumberOfElements(ptemp);

  for (i = 0; i < S; i++) {
    for (j = 0; j < D; j++) {
      k = small_ndx[i] + diff_ndx[j];
      Tbig[k] *= Tsmall[i];
    }
  }
}

