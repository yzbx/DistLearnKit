/* C mex version for marg_table_ndx.m in potential/Tables directory  */

#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]){
  mxArray *ptemp;
  double  *Tbig, *Tsmall, maximize, max, sum;
  int     i, j, k, S, D;
  int     *small_ndx, *diff_ndx;

  Tbig = mxGetPr(prhs[0]);
  maximize = (int)mxGetScalar(prhs[1]);

  ptemp = mxGetField(prhs[2], 0, "small");
  small_ndx = mxGetData(ptemp);
  S = mxGetNumberOfElements(ptemp);

  ptemp = mxGetField(prhs[2], 0, "diff");
  diff_ndx = mxGetData(ptemp);
  D = mxGetNumberOfElements(ptemp);

  plhs[0] = mxCreateDoubleMatrix(S, 1, mxREAL);
  Tsmall = mxGetPr(plhs[0]);

  if (maximize) {
    for (i = 0; i < S; i++) {
      max = -1e-20;
      for (j = 0; j < D; j++) {
		k = small_ndx[i] + diff_ndx[j];
    	if (Tbig[k] > max) max = Tbig[k];
      }
      Tsmall[i] = max;
    }
  } 
  else {
    for (i = 0; i < S; i++) {
      sum = 0;
      for (j = 0; j < D; j++) {
		k = small_ndx[i] + diff_ndx[j];
		sum += Tbig[k];
      }
      Tsmall[i] = sum;
    }
  }
}
