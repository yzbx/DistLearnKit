function Tbig = divide_by_table_ndxB(Tbig, Tsmall, ndx)
% DIVIDE_BY_TABLE_NDXB Tbig /= Tsmall
% Tbig = divide_by_table_ndxB(Tbig, Tsmall, ndx)

% Replace 0s by 1s before dividing. This is valid, Ts(i)=0 iff Tbig(i)=0.
ndx = double(ndx) + 1;
Tsmall = Tsmall(ndx);
Ts = Tsmall + (Tsmall == 0);
Tbig(:) = Tbig(:) ./ Ts(:);

