/* C mex version for marg_table_ndx.m in potential/Tables directory  */

#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  double *bigT, *smallT, maximize;
  int    i, I, J, N;
  int    *ndx;

  bigT = mxGetPr(prhs[0]);
  maximize = (int)mxGetScalar(prhs[1]);
  ndx = mxGetData(prhs[2]);

  I = mxGetM(prhs[2]);
  J = mxGetN(prhs[2]);

  N = I * J;

  plhs[0] = mxCreateDoubleMatrix(I, 1, mxREAL);  
  smallT = mxGetPr(plhs[0]); 

  if (maximize) {
    for (i = 0; i < N; i++) {
	  smallT[*ndx] = (smallT[*ndx] < bigT[i])? bigT[i] : smallT[*ndx];
      ndx++;
	}
  } 
  else{
    for(i = 0; i < N; i++) {
      smallT[*ndx++] += *bigT++;
    }
  }
}                                 
