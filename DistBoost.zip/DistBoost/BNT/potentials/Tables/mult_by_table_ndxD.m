function Tbig = mult_by_table_ndxD(Tbig, Tsmall, ndx)
% MULT_BY_TABLE_NDX Tbig *= Tsmall
% function Tbig = mult_by_table_ndxD(Tbig, Tsmall, ndx)
% 
% Written by Wei Hu

N = prod(size(Tbig));
D = prod(size(ndx));
S = N / D;
if (D == 1) | (S == 1)
   %Tbig = Tbig .* Tsmall;
   Tbig = Tbig(:) .* Tsmall(:);
else
  ndx = double(ndx);
  used = zeros(1,N);
  index = zeros(1,N);
  pointer = 1;
  temp = zeros(1,D);
  for i=1:S
    while used(pointer)== 1
      pointer = pointer + 1;
    end
    temp = ndx + pointer;
    index(temp) = i;
    used(temp) = 1;
    pointer = pointer + 1;
  end
  Ts = Tsmall(index);
  Tbig = Tbig(:) .* Ts(:); 
end
