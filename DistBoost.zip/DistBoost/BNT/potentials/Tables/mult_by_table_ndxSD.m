function Tbig = mult_by_table_ndx(Tbig, Tsmall, ndx)
% MULT_BY_TABLE_NDX Tbig *= Tsmall
% function Tbig = mult_by_table_ndx(Tbig, Tsmall, ndx)

small_ndx = double(ndx.small);
diff_ndx = double(ndx.diff);
S = length(small_ndx);
D = length(diff_ndx);

if 0
  for i=1:S
    for j=1:D
      k = diff_ndx(j) + small_ndx(i) + 1;
      Tbig(k) = Tbig(k) * Tsmall(i);
    end
  end
else
  big_ndx = 1 + repmat(diff_ndx, S, 1) + repmat(small_ndx(:), 1, D); % ndx(i,j) = k above
  Tbig(big_ndx(:)) = Tbig(big_ndx(:)) .* repmat(Tsmall(:), D, 1);
end
