function Tbig = divide_by_table_ndx(Tbig, Tsmall, ndx)
% DIVIDE_BY_TABLE_NDX Tbig /= Tsmall
% function Tbig = divide_by_table_ndx(Tbig, Tsmall, ndx)

small_ndx = double(ndx.small);
diff_ndx = double(ndx.diff);
S = length(small_ndx);
D = length(diff_ndx);

if 0
  for i=1:S
    for j=1:D
      k = diff_ndx(j) + small_ndx(i) + 1;
      if Tsmall(i) ~= 0
	Tbig(k) = Tbig(k) / Tsmall(i);
      end
    end
  end
else
  big_ndx = 1 + repmat(diff_ndx, S, 1) + repmat(small_ndx(:), 1, D); % ndx(i,j) = k above
  Ts = Tsmall + (Tsmall==0); % replace 0s by 1s
  Tbig(big_ndx(:)) = Tbig(big_ndx(:)) ./ repmat(Ts(:), D, 1);
end
