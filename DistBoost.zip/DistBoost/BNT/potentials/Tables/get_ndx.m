function ndx = get_ndx(id, ndx_type)

global SD_NDX  B_NDX  D_NDX

switch ndx_type
 case 'SD', ndx = SD_NDX{id};
 case 'D',  ndx = D_NDX{id};
 case 'B',  ndx = B_NDX{id};
 otherwise, error(['unrecognized index type ' ndx_type])
end
