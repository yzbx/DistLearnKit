function smallT = marg_table_ndxB(bigT, maximize, ndx)
% MARG_TABLE_NDXB Marg a dtable onto a smaller domain.
% smallT = marg_table_ndxB(bigT, maximize, ndx)

N = prod(size(bigT));
S = size(ndx, 1);
smallT = zeros(1,S);
if S==1
   if maximize
      smallT = max(bigT);
   else
      smallT = sum(bigT);
   end
   return
end

ndx = double(ndx)+1;
if maximize
   for i = 1:N
      smallT(ndx(i)) = max(smallT(ndx(i)) + bigT(i));
   end
else
   for i = 1:N
      smallT(ndx(i)) = smallT(ndx(i)) + bigT(i);
   end
end
