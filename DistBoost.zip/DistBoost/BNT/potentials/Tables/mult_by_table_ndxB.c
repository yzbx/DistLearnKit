/* C mex version for mult_by_table_ndxB.m in potential/Tables directory  */

#include "mex.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  double *bigT, *smallT, value;
  int    *ndx;
  int    i, j, N;  

  plhs[0] = mxDuplicateArray(prhs[0]);
  bigT = mxGetPr(plhs[0]);
  smallT = mxGetPr(prhs[1]); 
  ndx = mxGetData(prhs[2]);
  N = mxGetNumberOfElements(prhs[0]);
  j = mxGetNumberOfElements(prhs[2]);

  if(j == 1){
	value = smallT[*ndx];
	for (i = 0; i < N; i++) {
      *bigT++ *= value;
	}
  }
  else{
    for (i = 0; i < N; i++) {
      *bigT++ *= smallT[*ndx++];
	}
  }
}
