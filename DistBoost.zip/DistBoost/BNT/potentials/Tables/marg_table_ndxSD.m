function smallT = marg_table_ndxSD(bigT, maximize, ndx)
% MARG_TABLE_NDX Marg a dtable onto a smaller domain.
% function smallT = marg_table_ndx(bigT, maximize, ndx)

small_ndx = double(ndx.small);
diff_ndx = double(ndx.diff);
S = length(small_ndx);
D = length(diff_ndx);

if 0
  if maximize
    for i=1:S
      m = -inf;
      for j=1:D
	k = diff_ndx(j) + small_ndx(i) + 1;
	m = max(m, bigT(k));
      end
      smallT(i) = m;
    end
  else
    for i=1:S
      s = 0;
      for j=1:D
	k = diff_ndx(j) + small_ndx(i) + 1;
	s = s + bigT(k);
      end
      smallT(i) = s;
    end
  end  
else
  big_ndx = 1 + repmat(diff_ndx, S, 1) + repmat(small_ndx(:), 1, D); % ndx(i,j) = k above
  if S==1 % sum all of bigT down to a scalar - Matlab incorrectly converts row vector to column
    if maximize
      smallT = max(bigT(big_ndx));
    else
      smallT = sum(bigT(big_ndx));
    end    
  else
    if maximize
      smallT = max(bigT(big_ndx), [], 2);
    else
      smallT = sum(bigT(big_ndx), 2);
    end    
  end
end
