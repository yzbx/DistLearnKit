function Tsmall = marg_table_ndx(Tbig, maximize, ndx, ndx_type)
% MARG_TABLE_NDX Marginalize a dtable onto a smaller domain.
% function Tsmall = marg_table_ndx(Tbig, maximize, ndx, ndx_type)

switch ndx_type
 case 'SD', Tsmall = marg_table_ndxSD(Tbig, maximize, ndx);
 case 'D', Tsmall = marg_table_ndxD(Tbig, maximize, ndx);
 case 'B', Tsmall = marg_table_ndxB(Tbig, maximize, ndx);
 otherwise, error(['unrecognized ndx type ' ndx_type])
end
  
