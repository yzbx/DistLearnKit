function id = add_ndxB(bigdom, smalldom, ns)
% ADD_MULT_NDX Possibly add new multiplication indexes to the global cache
% id = add_mult_ndx(bigdom, smalldom, ns)
%
% ns is the node sizes of all nodes
% id is the identifier for the cache entry, new or existingg.

global B_NDX  B_UID_GEN   
[id, newid, B_UID_GEN] = mk_uid(B_UID_GEN, {ns(bigdom), find_equiv_posns(smalldom, bigdom)});
if newid
  B_NDX{id} = mk_ndxB(bigdom, smalldom, ns);
end
