function [small_ndx, diff_ndx] = mk_ndx(bigdom, smalldom, ns)
% MK_NDX Make the indices needed to speedup table manipulation
% [small_ndx, diff_ndx] = mk_ndx(bigdom, smalldom, ns)
%
% For an explanation, see test_mult_ndx1D.m

% small_ndx is an Sx1 vector, and diff_ndx is a Dx1 vector

S = prod(ns(smalldom));
subs = ind2subv(ns(smalldom), 1:S);
ns = ns(:)';
skip_sizes = [1 cumprod(ns(bigdom))]';
map = find_equiv_posns(smalldom, bigdom);
if isempty(smalldom)
  small_ndx = 0;
else
  small_ndx = (subs-1) * skip_sizes(map);
end

sz = ns(bigdom);
sz(map) = 1;
diffdom = mysetdiff(bigdom, smalldom);
D = prod(ns(diffdom));
subs = ind2subv(sz, 1:D);
diff_ndx = subv2ind(ns(bigdom), subs)' - 1; % we subtract 1 so both ndx arrays start from 0

small_ndx = int32(small_ndx);
diff_ndx = int32(diff_ndx);

