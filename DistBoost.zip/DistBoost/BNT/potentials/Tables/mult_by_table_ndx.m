function Tbig = mult_by_table_ndx(Tbig, Tsmall, ndx, ndx_type)
% MULT_BY_TABLE_NDX Tbig /= Tsmall
% function Tbig = mult_by_table_ndx(Tbig, Tsmall, ndx, ndx_type)

switch ndx_type
 case 'SD', Tbig = mult_by_table_ndxSD(Tbig, Tsmall, ndx);
 case 'D', Tbig = mult_by_table_ndxD(Tbig, Tsmall, ndx);
 case 'B', Tbig = mult_by_table_ndxB(Tbig, Tsmall, ndx);
 otherwise, error(['unrecognized ndx type ' ndx_type])
end
  
