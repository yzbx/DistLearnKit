function display(pot)

disp('utility potential object');
disp(struct(pot));
