function m = pot_to_marginal(pot)
% POT_TO_MARGINAL Convert a upot to a structure.
% m = pot_to_marginal(pot)

m.domain = pot.domain;
m.T = pot.p;
m.U = pot.u;

    
