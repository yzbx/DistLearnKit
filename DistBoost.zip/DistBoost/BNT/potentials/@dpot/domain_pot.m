function dom = domain_pot(pot)
% DOMAIN_POT Return the domain of this dpot.
% dom = domain_pot(pot)

dom = pot.domain;
