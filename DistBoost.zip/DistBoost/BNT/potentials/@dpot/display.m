function display(pot)

disp('discrete potential object');
disp(struct(pot));
