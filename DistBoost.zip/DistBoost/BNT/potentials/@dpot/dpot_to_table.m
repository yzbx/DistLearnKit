function T = dpot_to_table(pot)

T = pot.T;
