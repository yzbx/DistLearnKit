function [chunks, neglinks, S, D] = generate_constraints(X, y, p1, p2)
% generate_constraints : generate contextual constraints
% [chunks, neglinks, S, D] = generate_constraints(X, y, p1, p2)
%	X  - d*n data features
%   y  - 1*n class labels
%	p1 - percentage of positive constraints to be produced
%	p2 - percentage of positive constraints to be produced
% returns:
%	chunks   - n*1 vector: to mark chunket id of connected data examples
%   neglinks - k*k matrix: to count the negative links between chunklets 
%   S        - n*n pairwise similarity matrix
%   D        - n*n pairwise dissimilarity matrix

% Copyright (c) 2005-2006 Steven CH Hoi
% All rights Reserved

[d n] = size(X);
chunks = -ones(n,1);

%---------------------------------------------------------------
% 1. generate total pairwise constraints: 0.5*n*(n-1)
%---------------------------------------------------------------
C_pos=[]; %set of positive constraints
C_neg=[]; %set of negative constraints
for i=1:(n-1)
    % positive
    ind=find(y==y(i));
    ind=ind((find(ind>i)));
    C_pos(end+1:end+length(ind),:)=[i*ones(length(ind),1)';ind]';
    % negative
    ind=find(y~=y(i));
    ind=ind((find(ind>i)));
    C_neg(end+1:end+length(ind),:)=[i*ones(length(ind),1)';ind]';
end
n_pos=length(C_pos(:,1)); % number of total positive constraints
n_neg=length(C_neg(:,1)); % number of total negative constraints

%---------------------------------------------------------------
% 2. randomly produce pos/neg pairwise constraints
%---------------------------------------------------------------
% randomize pairwise constraints
pos_perm=randperm(n_pos);
neg_perm=randperm(n_neg);
% count the constraints to be produced
m_pos=ceil(p1*n_pos); % number of positive constraints 
m_neg=ceil(p2*n_neg); % number of positive constraints 

%---------------------------------------------------------------
% 3. form the chunklets by the generated positive constraints
%---------------------------------------------------------------
cid=1;
for i=1:m_pos,
    idx=pos_perm(i);
    x1=C_pos(idx,1); 
    x2=C_pos(idx,2);
    if (chunks(x1)==-1 && chunks(x2)==-1) % both are not allocated!
        chunks(x1)=cid;
        chunks(x2)=cid;
        cid=cid+1;
    elseif (chunks(x1)==-1) % x2 has been allocated with a chunklet id
        chunks(x1)=chunks(x2); 
    elseif (chunks(x2)==-1) % x1 has been allocated with a chunklet id
        chunks(x2)=chunks(x1);        
    else % both have been allocated with a chunklet id
        if (chunks(x1)~=chunks(x2))
            n_min=min(chunks(x1),chunks(x2));
            n_max=max(chunks(x1),chunks(x2));        
            % merge the two chunklets to the small index one
            ind=find(chunks==n_max);
            chunks(ind)=n_min;
            % replace the last chunklet to the large index of (x1, x2)
            ind=find(chunks==(cid-1));
            chunks(ind)=n_max;
            % reduce number of chunklets after merging two chunklets
            cid=cid-1;
        end
    end    
end

%---------------------------------------------------------------
% 4. count the negative links between chunklets
%---------------------------------------------------------------
neglinks=zeros((cid-1),(cid-1));
for i=1:m_neg
    idx=neg_perm(i);
    x1=chunks(C_neg(idx,1));
    x2=chunks(C_neg(idx,2));
    if (x1>0 && x2>0)
        neglinks(x1,x2)=neglinks(x1,x2)+1;
        neglinks(x2,x1)=neglinks(x2,x1)+1;
    end
end

%---------------------------------------------------------------
% 5. count the similarity and dissimilarity matrices (S,D)
%---------------------------------------------------------------
S = eye(n,n);
for i=1:m_pos
    idx=pos_perm(i);    
    x1=C_pos(idx,1);
    x2=C_pos(idx,2);
    S(x1,x2)=1;
    S(x2,x1)=1;
end
D = zeros(n,n);
for i=1:m_neg
    idx=neg_perm(i);    
    x1=C_neg(idx,1);
    x2=C_neg(idx,2);
    D(x1,x2)=1;
    D(x2,x1)=1;
end
% Count K_c (number of resulting connected components)
K_c=length(find(chunks==-1)); % count number of '-1' (single points)
if (K_c>0)
    K_c=(K_c-1)+length(unique(chunks));
else
    K_c=K_c+length(unique(chunks));
end
fprintf(1,'K_c(connected components)= %d\n',K_c); 
fprintf(1,'K_c Pecentage (K_c/n)= %.3f\n',K_c/n); 
